/* XPM */
/* $XConsortium: Dtplus.m.pm /main/3 1995/07/18 16:47:39 drk $ */
static char * Dtplus_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"10 10 2 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s foreground	m black	c white",
/* pixels */
"    ..    ",
"    ..    ",
"    ..    ",
"    ..    ",
"..........",
"..........",
"    ..    ",
"    ..    ",
"    ..    ",
"    ..    "};
