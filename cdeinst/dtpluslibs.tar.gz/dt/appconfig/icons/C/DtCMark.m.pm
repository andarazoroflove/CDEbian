/* XPM */
/* $XConsortium: DtCMark.m.pm /main/3 1995/07/18 16:19:16 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMark_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 11 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray6     m black c #636363636363",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray7     m black c #424242424242",
"&    s iconGray1     m white c #dededededede",
/* pixels */
"                       .........",
" XXXXXXXXXXXXXXXXXXXXXo.........",
" XOOX+X+++X+X+XXXXXXXXo.........",
" XXXXXXXXXXXXXXXXXXXXXo.........",
" X@@@@@@@@@@@@@@@@@@@Xo.........",
" XXXX@XXXXXXXXXXXXXXXXo.........",
" XOOX@O@O@O@O@X@XXXXXXo.........",
" XXXXXX@XX@XX@XXXXXXXXo.........",
" X@@@@@@@@@@@@@@@@@@@Xo.........",
" XXXXXXXXXXXXXXXXXXXXX#.........",
" XOO@+@++++@X++XXXXXXX#.........",
" XXX@@XXXXX@XXXXXXXXXX#.........",
" X@@@@@@@@@@@@@@@@@@@X#.........",
" XXXX@XXXXX@X++XXXXXXX#.........",
" XOO@X+@+++X+XX+X++XXX#.........",
" XXXXXXXXXXXXXXXXXXXXXo.........",
" X@@@@@X@@@@@@@@     o          ",
" XXXXXXXXXXXXXXX $$$ O$$$$ O$$$%",
" XX@+++X++@X+@X+ $   +     O X$%",
" XXXXX@XXXXXXXXX $   $    &+ X+%",
" X@@@@@@@@@@@@@@ $ + +  $    X+%",
" XXXXX@XX@XXXXXX $ $+ ++ ++  X+%",
" XX+++XX++++++++ $           X+%",
" XXXXXXXX@XX@XXX $   O+ $+   X+%",
" X@@@@@@@@@@@@@@ $   +@ +@   X+%",
" XXXX@XXXXXXXXXX $           X+%",
" XX+++X++X++X++X $XXXXXXXXXXXX+%",
" XX@XXX@XXXXXXXX $$++++++++++++%",
" X@@@@@@@@@@@@@@ %%%%%%%%%%%%%%%",
" XXXXXXXXXXXXXXX@@@@@@@.........",
" XXXXXXXXXXXXXXXXXXXXXo.........",
" oooooooooooooooooooooo........."};
