/* XPM */
/* $XConsortium: Dtinfbc.t.pm /main/3 1996/06/17 13:53:58 rcs $
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
static char * DtInfoBC_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray3	m white	c #adadadadadad",
"X	s iconGray8	m black	c #212121212121",
"o	s iconGray4	m white	c #949494949494",
"O	s iconGray2	m white	c #bdbdbdbdbdbd",
"+	s iconGray7	m black	c #424242424242",
"@	s iconGray5	m black	c #737373737373",
"#	s iconGray6	m black	c #636363636363",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"    ..X.o   o.X ",
"  O.oo+.@+@Xo#X ",
"  O#oo+.@+@Xo#X ",
"  O#ooX@@@@X@#X ",
"  O#ooX.@+@Xo#X ",
"  O#ooXO@+@X@#X ",
"  O#ooX@@@@Xo#X ",
"  O#ooX@@++X+#X ",
"  O#ooX@@X@Xo#X ",
"  .XXXXXXXXXXXX ",
"                ",
"                "};
