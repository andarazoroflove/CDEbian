/* XPM */
/* $XConsortium: Dthover.t.pm /main/3 1995/07/18 17:10:53 drk $ */
static char * Dthover_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X	s iconColor1	m black	c black",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray7     m black c #424242424242",
"+	s iconColor5	m black	c blue",
"@	s iconColor6	m white	c yellow",
"#	s iconColor3	m black	c red",
"$    s iconGray4     m white c #949494949494",
/* pixels */
"                ",
"  ...........X  ",
"  oooooooooooX  ",
"  oXXXXXXXXXXX  ",
"  oOO.O.OOOOOX  ",
"  oOOOOOOOOOOX  ",
"  o.......X.XX  ",
"  o......+XX.X  ",
"  o..@.@.....X  ",
"  o..X.X.....X  ",
"  o...X......X  ",
"  o#.X.X.....X  ",
"  o#.$X.X.X..X  ",
"  o$$$$$$$$$$X  ",
"  XXXXXXXXXXXX  ",
"                "};
