/* XPM */
/* $XConsortium: Dttvnil.s.pm /main/3 1995/07/18 16:52:40 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * tree_nil_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"14 14 2 1 0 0",
/* colors */
"     s selectColor m white c #737373737373",
".	s foreground	m white	c white",
/* pixels */
"              ",
"              ",
"     ...  .   ",
"    .   ..    ",
"   .    ..    ",
"  .    .  .   ",
"  .   .   .   ",
"  .  .    .   ",
"  . .     .   ",
"   .     .    ",
"  . .   .     ",
" .   ...      ",
"              ",
"              "};
