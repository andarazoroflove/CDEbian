/* XPM */
/* $XConsortium: DtCMapt.t.pm /main/3 1995/07/18 16:19:08 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMapt_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor3	m black	c red",
"X	s iconColor2	m white	c white",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray3     m white c #adadadadadad",
"@    s iconGray5     m black c #737373737373",
"#    s iconGray6     m black c #636363636363",
"$	s iconColor6	m white	c yellow",
"%	s iconColor1	m black	c black",
/* pixels */
"                ",
"          .     ",
" XX XXXXX..o XX ",
"XOo XOOO+Xo.@XO#",
"XOOoOOO+XXO@oOO#",
"XOOOOO+O$OoOOOO#",
"XOOOO+O$$oOOOOO#",
"XOOO+O$$oOOOOOO#",
"XOO+O$$oO@@@OOO#",
"XO+O$$oOOO%%%%O#",
"X+X$$oOO@%O%OO%#",
"XX%OoOOOO%O%%%%#",
"X%@@OO@@O%OOOO%#",
"XOOOOOOOO%OOOO%#",
"XOOOOOOOOO%%%%O@",
" oooooooooooooo "};
