/* XPM */
/* $XConsortium: Dtinlib.m.pm /main/3 1996/06/17 13:54:11 rcs $
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
static char * Dtinlib_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconGray1	m white	c #dededededede",
"X	s iconGray3	m white	c #adadadadadad",
"o	s bottomShadowColor	m black	c #636363636363",
"O	s iconGray7	m black	c #424242424242",
"+	s iconGray8	m black	c #212121212121",
"@	s iconGray5	m black	c #737373737373",
"#	s iconGray4	m white	c #949494949494",
"$	s iconGray6	m black	c #636363636363",
"%	s iconGray2	m white	c #bdbdbdbdbdbd",
"&	s iconColor8	m black	c magenta",
"*	s iconColor3	m black	c red",
"=	s iconColor5	m black	c blue",
/* pixels */
"                                ",
"                                ",
"                                ",
"               ...              ",
"              .....             ",
"        XXXXo .....O   XXXX+    ",
"        X@#$+#.....O   ###$+    ",
"    %%X+&#@*+#@...+@O$+##@O+    ",
"    %X@+#@#$+#@@OO+O@=+#$@@+    ",
"    %#@+#@@*+#@@@$+OO$+#$@@+    ",
"    %X@+#@#$+#@...+O@=+##@@+    ",
"    %#@+&#@*$......OO$+#O@@+    ",
"    %X@+#@#$.......=@=+###@+    ",
"    %X@+&#@*OO.....OO$+#O@@+    ",
"    %#@+#@#$OX.....=@=+@@@@+    ",
"    %X@+&#@*+#.....OO$+@$@@+    ",
"    %#@+#@#$+#.....=@=+@#@@+    ",
"    %#@+&#@*+#.....OO$+@$@@+    ",
"    %#@+#@#$+#.....=@=+@@@@+    ",
"    %X@+&#@*+#.....OO$+@##@+    ",
"    %X@+#@#$+#.......=+@#@@+    ",
"    %X@+&#@*+#......O$+@#@@+    ",
"    %X@+#@#$+#$...+=@=+@O@@+    ",
"    %X@+&#@*+#@OO$+OO$+@#@@+    ",
"    %X@+#@#$+#@@@$+=@=+@#@@+    ",
"    %X@+&#@*+#@@@$+OO$+@#@@+    ",
"    X+++++++++++++++++++++++    ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                "};
