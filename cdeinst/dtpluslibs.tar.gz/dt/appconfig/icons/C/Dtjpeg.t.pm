/* XPM */
/* $XConsortium: Dtjpeg.t.pm /main/3 1995/07/18 16:42:28 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtjpeg_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
".    s iconGray3     m white c #adadadadadad",
"X	s none	m none	c none",
"o    s iconGray8     m black c #212121212121",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray6     m black c #636363636363",
"@	s iconColor2	m white	c white",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"&	s iconColor5	m black	c blue",
/* pixels */
"..........XXXXXX",
".oooooooooXXXXXX",
".ooO....ooXXXXXX",
".ooO+@+.ooXXXXXX",
".ooO@.@.ooXXXXXX",
".oooooooooXXXXXX",
".oo$%%%%ooXXXXXX",
".ooo%%%%&&&&&&XX",
".ooo%%%%&&&&@&XX",
".ooo%%%%&&&&@&XX",
".ooooooo&&&&@&XX",
".oo+@@@+&@&&@&XX",
".oo++@++&&@@&&XX",
".oo+++++&&&&&&XX",
".oo+++++ooXXXXXX",
".oooooooooXXXXXX"};
