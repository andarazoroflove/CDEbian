/* XPM */
/* $XConsortium: Dtassem.t.pm /main/3 1995/07/18 16:29:05 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtassem_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray8     m black c #212121212121",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray7     m black c #424242424242",
"#	s iconColor5	m black	c blue",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" XOo+XXXXXXXo...",
" XXXXXXXXXXXo...",
" XOOXXXXooXXo...",
" XXXXXXXXXXXo...",
" X@@X@XX@@######",
" XXXXXXXXX##   #",
" X@@@XXX@@# ####",
" XXXXXXXXX##  ##",
" X@X@@XXX@#### #",
" XXXXXXXXX#   ##",
" X@@@XXXXX######",
" XXXXXXXXXXXo...",
" oooooooooooo..."};
