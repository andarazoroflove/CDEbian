/* XPM */
/* $XConsortium: portrait.pm /main/3 1996/08/12 18:44:11 cde-hp $ */
/*
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */

static char * portrait [] = {
/* width height ncolors cpp [x_hot y_hot] */
"22 28 3 1 0 0",
/* colors */
" 	s iconColor1	m black	c black",
".	s background	m black	c #969696969696",
"X	s iconColor2	m white	c white",
/* pixels */
"                 .....",
" XXXXXXXXXXXXXXX  ....",
" XXXXXXXXXXXXXXX X  ..",
" XXXXXXXXXXXXXXX XXX .",
" XXXXXXXXXXXXXXX      ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXX  XXXXXXXXX ",
" XXXXXXXXX  XXXXXXXXX ",
" XXXXXXXXX  XXXXXXXXX ",
" XXXXXXXX  X XXXXXXXX ",
" XXXXXXXX  X XXXXXXXX ",
" XXXXXXX  XXX XXXXXXX ",
" XXXXXXX  XXX XXXXXXX ",
" XXXXXX        XXXXXX ",
" XXXXXX  XXXXX XXXXXX ",
" XXXXXX  XXXXX XXXXXX ",
" XXXXX  XXXXXX  XXXXX ",
" XXXX     XXX    XXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXX ",
"                      "};
