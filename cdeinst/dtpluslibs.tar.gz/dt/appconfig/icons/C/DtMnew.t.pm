/* XPM */
/* $XConsortium: DtMnew.t.pm /main/3 1995/07/18 17:09:21 drk $ */
static char * DtMnew_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray7     m black c #424242424242",
"o    s iconGray1     m white c #dededededede",
"O	s iconColor3	m black	c red",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray6     m black c #636363636363",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                ",
"          .X    ",
"         .ooX   ",
"        .oOooX  ",
"  ooooo.oOooooX ",
"  ++++.ooooooooX",
" .ooo.oooooooo@+",
" .oo.oooo#ooo@+ ",
" .o.o#oo#ooo@+$ ",
" ..o#oo#ooo@+$$ ",
"....$$oooo@+....",
".o%$@$$oo@+.++@X",
".o%$+......+++@X",
".o%$++++++++++@X",
".o%$++++++++++@X",
"@@@@@@@@@@@@@@@X"};
