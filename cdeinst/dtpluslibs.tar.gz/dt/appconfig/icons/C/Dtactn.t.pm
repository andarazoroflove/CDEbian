/* XPM */
/* $XConsortium: Dtactn.t.pm /main/3 1995/07/18 16:26:44 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * action [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray8     m black c #212121212121",
"$	s iconColor5	m black	c blue",
"%	s iconColor2	m white	c white",
"&    s iconGray2     m white c #bdbdbdbdbdbd",
"*	s iconColor3	m black	c red",
/* pixels */
" ..........Xo.. ",
". O O O O +.@oO@",
".O O O O O#..# @",
". O O ...$ .# O@",
".O O .@@+$.# O @",
". % .@OX$#X+O O@",
".O @@O+$X$##..+.",
". O O &*X O ###X",
".O O O#&*O O O @",
". O O&&#&.O O O@",
".O O .#OX#.O O @",
". O&.#O O.# O O@",
".O .#O O.# O O @",
". .#O O.# O O O@",
"..#O O X.O O O @",
" #.@@@@@@@@@@@@ "};
