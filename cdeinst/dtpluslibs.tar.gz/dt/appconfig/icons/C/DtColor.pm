/* XPM */
/* $XConsortium: DtColor.pm /main/3 1995/07/18 16:20:44 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * ColorCDE [] = {
/* width height ncolors cpp [x_hot y_hot] */
"43 37 16 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray3     m white c #adadadadadad",
"+	s iconColor8	m black	c magenta",
"@	s iconColor6	m white	c yellow",
"#    s iconGray6     m black c #636363636363",
"$    s topShadowColor m white c #bdbdbdbdbdbd",
"%    s iconGray8     m black c #212121212121",
"&	s iconColor3	m black	c red",
"*    s iconGray5     m black c #737373737373",
"=    s iconGray1     m white c #dededededede",
"-	s iconColor5	m black	c blue",
";	s iconColor4	m white	c green",
":	s iconColor1	m black	c black",
/* pixels */
"                                           ",
"                                           ",
"                                           ",
"                                           ",
"                    ..........             ",
"                ....XXXXXXXXXX...          ",
"              ..XXXXoOOOOOOOOoXXX..        ",
"            ..XXoOOOOOOOOOOOOOOOoXX..      ",
"          ..XXoOOOOOOOOOOO+++++OOOoXX.     ",
"         .XXoOOO@O@OOOOOO+++++++OOOOOX.    ",
"        .XooOOO@O@O@OOOO++++++++#OOOOO.    ",
"       .XOOOO@@@@@@OOOOO++++++++#OOOOO.$   ",
"      .XOOOO@@@@@@O@OOOOO+++++##OOOOOO%$   ",
"     .XOOOO@@@@@@@@&OOOOOOO###OOOOOOO*%$   ",
"    .XoOOOOO@@@@@@&OOOOOOOOOOOOOOOOO%%$    ",
"   .XoOOO&OOOO@@@&OOOOOOOOOOOOOOOO*%%$     ",
"   .XOO&&O&OOOOOOOOOOOOOOOOOOOOOO%%$$      ",
"  .XoOO&&&O&OOOOOOOOOO%%%%%*OOOO%$$        ",
"  .XOO&&&&&&&&OOOOOOO%%    =OOO%$    ....  ",
"  .XOO&&&&&&&&OOOOOOO%     =OOO%$  ..==o$  ",
"  .XO&O&&&&&&#OOOOOOO%     =OOO=...o=oOO$  ",
"  .XOO&&&&&&#OOOOOOOO*=====OOOOo====OOO%$  ",
"  .XOOOO&&&#OOOO-O-O-OOOOOOOOOOOOOOOOO%$   ",
"  .XoOOO###OOOO-O-O-OOOOOOOOOOO;;;OOOO%$   ",
"   .XOOOOOOOOO--------OOOOOOO-;-;;;OO%$    ",
"   .XoOOOOOOO-O--------OOOOO-;-;-;;OO%$    ",
"    .X*OOOOOOO---------OOOOO;-;-;;OO%$     ",
"      o%%OOOOOO-------:OOOOO---OOOO%$$     ",
"       $$%%OOOOOO---:OOOOOOOOOOOOO%$$      ",
"        $$$%%%OOOOOOOOOOOOOOOOOO%%$$       ",
"          $$$$%%%OOOOOOOOOOOOO%%$$$        ",
"             $$$$%%%%%%%%%%%%%$$$          ",
"                $$$$$$$$$$$$$$$            ",
"                                           ",
"                                           ",
"                                           ",
"                                           "};
