/* XPM */
/* $XConsortium: DtABcas.pm /main/3 1995/07/18 16:12:38 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABcas_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 8 1 0 0",
/* colors */
"     s iconGray2     m white c #bdbdbdbdbdbd",
".	s iconColor1	m black	c black",
"X    s iconGray5     m black c #737373737373",
"o    s iconGray6     m black c #636363636363",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray3     m white c #adadadadadad",
"#	s iconColor2	m white	c white",
/* pixels */
"                           .",
" XXXXXXX..............XXXXX.",
" XXXXXXX.ooooooooooooOXXXXX.",
" XXXXXXX.ooooooooooooOXXXXX.",
".........OOOOOOOOOOOOO......",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@##########@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@########@@@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@##########@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@########@@@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@##########@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O@@@@@@@@@@@@.++++++",
"++++++++O.............++++++",
"++++++++++++++++++++++++++++"};
