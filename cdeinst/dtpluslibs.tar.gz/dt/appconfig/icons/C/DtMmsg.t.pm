/* XPM */
/* $XConsortium: DtMmsg.t.pm /main/3 1995/07/18 16:22:42 drk $ */
static char * DtMmsg_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray1     m white c #dededededede",
"O	s iconColor4	m white	c green",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray3     m white c #adadadadadad",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"...............X",
".oooooooooooooOX",
".o+@ooooooo#+oOX",
".ooooooooooooooX",
".ooooo+o+o+ooooX",
".oooo@o@o@oooooX",
".ooooo+o+ooooooX",
".ooooooooooooooX",
".XXXXXXXXXXXXXXX"};
