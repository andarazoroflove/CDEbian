/* XPM */
/* $XConsortium: DtPrtjb.t.pm /main/3 1995/07/18 16:23:50 drk $ */
static char * prtjob_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s topShadowColor m white c #bdbdbdbdbdbd",
"o	s iconColor2	m white	c white",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor1	m black	c black",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray5     m black c #737373737373",
/* pixels */
" ..............X",
" .ooooooooooooOX",
" .o+++oooo++ooOX",
" .ooooooooooo@OX",
" .oo+++++++ooOXX",
".ooooooooooooOX ",
".oo++++++++ooOX ",
".ooooooooooooOX ",
" .oo+++++++oo@#X",
" .ooooooooooooOX",
" .oo+++++++++oOX",
" .ooooooooooooOX",
" .oo++++++++o@OX",
".oooooooooooo+XX",
"+++++++++++++OX ",
"XXXXXXXXXXXXXXX "};
