/* XPM */
/* $XConsortium: DtMmsg.l.pm /main/3 1995/07/18 16:22:27 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtMmsg_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray4     m white c #949494949494",
"X	s iconColor1	m black	c black",
"o	s iconColor2	m white	c white",
"O    s iconGray1     m white c #dededededede",
"+	s iconColor4	m white	c green",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray3     m white c #adadadadadad",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
".............................................X  ",
".ooooooooooooooooooooooooooooooooooooooooooooX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOO..OOOO..OO+@+OX  ",
".o##O###O##OOOOOOOOOOOOOOOOOOOOOO..O.OO.O@+@OX  ",
".oOO$OO$OOO$OOOOOOOOOOOOOOOOOOO..OOO.OO.O@+@OX  ",
".o#$#O##O##OOOOOOOOOOOOOOOOOOOOOO..OO..OO+@+OX  ",
".o$OOO$OO$OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOO.OOOO.OO.OOO.OOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOO###.O##O###O###OOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOO.OO.OOOOO.OOO.OOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOO.OOO.OOOO.OOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOO##O####O##O####OOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOO.OOO.OOOO.OOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".oOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOX  ",
".XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX  "};
