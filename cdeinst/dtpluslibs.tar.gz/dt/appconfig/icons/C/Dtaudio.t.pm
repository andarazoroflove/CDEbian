/* XPM */
/* $XConsortium: Dtaudio.t.pm /main/3 1995/07/18 16:29:55 drk $ */
static char * Dtaudio_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray4     m white c #949494949494",
"%    s iconGray6     m black c #636363636363",
/* pixels */
"            ....",
" XXXXXXXXXXo....",
" XXXXXXXXXXo....",
" XX XXXXXXXo....",
" XX  XXXXXXo....",
" XX   XXXXXo....",
" XX O    XXo....",
" XXO+@# #XXo....",
" XX$++#O#XXo....",
" XX$++#%#XXo....",
" XX++####XXo....",
" XX+##XXXXXo....",
" XX+#XXXXXXo....",
" XX#XXXXXXXo....",
" XXXXXXXXXXo....",
" ooooooooooo...."};
