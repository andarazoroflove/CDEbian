/* XPM */
/* $XConsortium: FpPrtmg.t.pm /main/3 1995/07/18 16:54:46 drk $ */
static char * DtPrtmg_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor1	m black	c black",
"o	s iconColor2	m white	c white",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray1     m white c #dededededede",
"@	s iconColor4	m white	c green",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray3     m white c #adadadadadad",
/* pixels */
"     .XX.XXXX   ",
"     .ooooooX   ",
"     .ooooooX   ",
"    X.ooooooXXX ",
"   XOXXXXXXXXOOX",
"   X+++++++++++X",
"  .XXXXXXX+@@@+X",
"  .ooooooX+###+X",
"  XooooooX+++++X",
" .XooooooXXXX++X",
"XOXooooooXOOOXX ",
"X$XXXXXXXXX+$X  ",
"X$+++++++@@@$X  ",
"X$+++++++###$X  ",
".$++++++++++$X  ",
" XXXXXXXXXXXX   "};
