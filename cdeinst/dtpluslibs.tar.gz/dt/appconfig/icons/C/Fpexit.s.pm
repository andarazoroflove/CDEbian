/* XPM */
/* $XConsortium: Fpexit.s.pm /main/3 1995/07/18 16:56:42 drk $ */
static char * Fpexit_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray8     m black c #212121212121",
/* pixels */
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"........................",
".XXXXXXXXXXXXXXXXXXXXXXX",
".XooooooooooooooooooooOX",
".Xo++++o+ooo+oOo+++++oOX",
".Xo+oooo+ooo+o+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+ooooo+++oo+ooo+oooOX",
".Xo+oooooo+ooo+ooo+oooOX",
".Xo+++oooo+ooo+ooo+oooOX",
".Xo+ooooo+++oo+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+ooooo+o+oo+ooo+oooOX",
".Xo+oooo+ooo+o+ooo+oooOX",
".Xo++++o+ooo+o+ooo+oooOX",
".XooooooooooooooooooooOX",
"OXOOOOOOOOOOOOOOOOOOOOOX",
"OXXXXXXXXXXXXXXXXXXXXXXX"};
