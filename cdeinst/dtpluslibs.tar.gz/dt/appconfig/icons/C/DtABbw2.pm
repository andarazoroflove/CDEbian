/* XPM */
/* $XConsortium: DtABbw2.pm /main/3 1995/07/18 16:12:29 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABbw2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray1     m white c #dededededede",
".    s iconGray6     m black c #636363636363",
"X    s iconGray7     m black c #424242424242",
"o    s iconGray4     m white c #949494949494",
"O	s iconColor2	m white	c white",
/* pixels */
"                            ",
" ..........................X",
" ..........................X",
" ooooooooooooooooooooooooooX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" oOOOOOOOOOOOOOOOOOOOOOOOOoX",
" ooooooooooooooooooooooooooX",
" XXXXXXXXXXXXXXXXXXXXXXXXXXX"};
