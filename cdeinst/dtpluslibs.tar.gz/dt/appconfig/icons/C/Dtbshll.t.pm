/* XPM */
/* $XConsortium: Dtbshll.t.pm /main/3 1995/07/18 16:32:28 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtbshll_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray4     m white c #949494949494",
"+	s iconColor5	m black	c blue",
/* pixels */
"            ....",
" XXXXXXXXXXo....",
" XXXXOOXXXXo....",
" XXOOOOOOXXo....",
" XOOXOOXOOXo....",
" OXOXOOXOXOo....",
" OOOXOOXOOOo....",
" XOXOOOOXO++++++",
" OXOXOOXOX+   ++",
" XOXOOOOXO+ ++ +",
" XOXOOOOXX+   ++",
" XXOOOOOOX+ ++ +",
" XXXXOOXXX+   ++",
" XXXXXXXXX++++++",
" XXXXXXXXXXo....",
" ooooooooooo...."};
