/* XPM */
/* $XConsortium: Dtfphlp.m.pm /main/3 1995/07/18 16:38:00 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * fphelp [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 15 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s iconGray3     m white c #adadadadadad",
"o    s iconGray5     m black c #737373737373",
"O	s iconColor1	m black	c black",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray7     m black c #424242424242",
"$	s iconColor5	m black	c blue",
"%	s iconColor6	m white	c yellow",
"&    s topShadowColor m white c #bdbdbdbdbdbd",
"*    s background    m black c #949494949494",
"=	s iconColor8	m black	c magenta",
"-	s iconColor3	m black	c red",
";    s bottomShadowColor m black c #636363636363",
/* pixels */
"                                ",
"    ........................    ",
"    XooooooooooooooooooooooO    ",
"    Xo++o+++o++ooooooooooooO    ",
"    XooooooooooooooooooooooO    ",
"    .OOOOOOOOOOOOOOOOOOOOO@O    ",
"    .O####################@O    ",
"    .O####################@O    ",
"    .O###++#++#+##########@O    ",
"    .O####################@O    ",
"    .O####################@O    ",
"    .O....................@O    ",
"    .O..........$$$.OoO#O.@O    ",
"    .O..........$.$.oOoOo.@O    ",
"    .O....................@O    ",
"    .O...%%%%%%%..........@O    ",
"    .O....................@O    ",
"&&&&&&&&&&&&&&&&&&&&&*&*&*&*&*&*",
"********************&***********",
".@#*#%@#**.XX**.#@#*&**OOOOOO*##",
"#@**.#@@**##@**@#@@*&***********",
"=$@*@-$@**##.**@#$@*&***********",
"@=**#@@#**###**@#@#*&%*######*OO",
"********************&***********",
";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;",
"    .O....#.####.#.##.##..@O    ",
"    .O....................@O    ",
"    .O..........$$$$$$$$$.@O    ",
"    .O....................@O    ",
"    .@@@@@@@@@@@@@@@@@@@@@@O    ",
"    OOOOOOOOOOOOOOOOOOOOOOOO    ",
"                                "};
