/* $XConsortium: Dtinlib.t_m.bm /main/2 1996/03/29 14:12:26 barstow $
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
#define Dtinlib.t_m.bm_width 16
#define Dtinlib.t_m.bm_height 16
#define Dtinlib.t_m.bm_x_hot 0
#define Dtinlib.t_m.bm_y_hot 0
static unsigned char Dtinlib.t_m.bm_bits[] = {
   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x71, 0xfc, 0x7f,
   0xfc, 0x7f, 0xfc, 0x7f, 0xfc, 0x7f, 0xfc, 0x7f, 0xfc, 0x7f, 0xfc, 0x7f,
   0xfc, 0x7f, 0xfc, 0x7f, 0x00, 0x00, 0x00, 0x00};
