/* XPM */
/* $XConsortium: Dtcmprs.t.pm /main/3 1995/07/18 17:10:10 drk $ */
static char * Dtcmprs_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray5     m black c #737373737373",
"O	s iconColor1	m black	c black",
"+    s iconGray6     m black c #636363636363",
"@    s iconGray8     m black c #212121212121",
"#	s iconColor5	m black	c blue",
"$    s iconGray4     m white c #949494949494",
/* pixels */
"             ...",
" XXXooooOXXXO...",
" XXXX++OXXXXO...",
" XXXXXOXXXXXO...",
" XXXXXXXXXXXO...",
" oXXXXOXXXXoO...",
" o+XXOXOXX+oO...",
" o+@XXOX########",
" o@XXOXO####   #",
" @XXXXOX###### #",
" XXXXXXX##### ##",
" XXXXX@X#### ###",
" XXXX++@# ##   #",
" XXXoooo########",
" XXXXXXXX$$$$...",
" OOOOOOOOOOOO..."};
