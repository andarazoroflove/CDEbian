/* XPM */
/* $XConsortium: DtABtmp2.pm /main/3 1995/07/18 16:16:12 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABtmp2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 10 1 0 0",
/* colors */
"     s iconGray3     m white c #adadadadadad",
".	s iconColor1	m black	c black",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray1     m white c #dededededede",
"$	s iconColor2	m white	c white",
"%    s iconGray4     m white c #949494949494",
/* pixels */
"                            ",
"          .........         ",
"         .XXXXXXXXX.        ",
"        .ooooooooooo.       ",
"        .O+++++++++@.       ",
"        .O.........@.       ",
"        .O.o..ooo..@.       ",
"        .O.........@.       ",
"        .O.#.#.##..@.       ",
"        .O.........@.       ",
"        .O.........@.       ",
"        .O$$$$$$$$$@.       ",
"         ...........        ",
"          .%%%%%%%.         ",
"       ...............      ",
"      .ooooooooooooooo.     ",
"     .oo++o++o++o+o++oo.    ",
"    .ooooooooooooooooooo.   ",
"    .....................   ",
"                            "};
