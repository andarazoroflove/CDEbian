/* XPM */
/* $XConsortium: Dtinfbk.t.pm /main/6 1996/06/17 13:53:51 rcs $
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
static char * Dthvol_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X	s iconGray2	m white	c #bdbdbdbdbdbd",
"o	s iconGray5	m black	c #737373737373",
"O	s iconColor1	m black	c black",
"+	s iconColor6	m white	c yellow",
/* pixels */
"            ....",
" XoXXXXXXXXO....",
" XoXXXXXXXXOO...",
" XoXOXOOOOXOO...",
" XoXXX++XXXOO...",
" XoXXX++XXXOO...",
" XoXXXXXXXXOO...",
" XoXoo++XoXOO...",
" XoXX+++XXXOO...",
" XoXXX++XXXOO...",
" XoXXX++XXXOO...",
" XoXXX++XXXOO...",
" XoXXo+++oXOO...",
" XoXXXXXXXXOO...",
" OOOOOOOOOOOO...",
". OOOOOOOOOOO..."};
