/* XPM */
/* $XConsortium: Dtminus.m.pm /main/3 1995/07/18 16:45:41 drk $ */
static char * Dtminus_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"10 10 2 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s foreground	m black	c white",
/* pixels */
"          ",
"          ",
"          ",
"          ",
"..........",
"..........",
"          ",
"          ",
"          ",
"          "};
