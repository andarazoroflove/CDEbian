/* XPM */
/* $XConsortium: DtABopm.pm /main/3 1995/07/18 16:14:50 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * option_menu_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 4 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".    s iconGray1     m white c #dededededede",
"X    s iconGray3     m white c #adadadadadad",
"o	s iconColor1	m black	c black",
/* pixels */
"                            ",
"                            ",
"                            ",
"                            ",
" .......................... ",
" .XXXXXXXXXXXXXXXXXXXXXXXXo ",
" .XXXXXXXXXXXXXXXXXXXXXXXXo ",
" .XXXXXXXXXXXXXXXX......oXo ",
" .XXXXXXXXXXXXXXXX.XXXXXoXo ",
" .XXXXXXXXXXXXXXXX.ooooooXo ",
" .XXXXXXXXXXXXXXXXXXXXXXXXo ",
" .XXXXXXXXXXXXXXXXXXXXXXXXo ",
" .XXXXXXXXXXXXXXXXXXXXXXXXo ",
" .ooooooooooooooooooooooooo ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            "};
