/* XPM */
/* $XConsortium: DtABlyr.pm /main/3 1995/07/18 16:14:09 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABlyr2_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray1     m white c #dededededede",
".    s iconGray4     m white c #949494949494",
"X    s iconGray8     m black c #212121212121",
"o    s iconGray3     m white c #adadadadadad",
"O    s iconGray7     m black c #424242424242",
/* pixels */
"                            ",
" ..........................X",
" .XXXXXXXXXXXXXXXXXXXXXXXX.X",
" .Xooooooooooooooooooooooo.X",
" .Xooooooooooooooooooooooo.X",
" .XoOOOOOOOOOOOOOOOOOooooo.X",
" .XoOoooooooooooooooOooooo.X",
" .XoOoOOOOOOOOOOOOOOOOOooo.X",
" .XoOoOoooooooooooooooOooo.X",
" .XoOoOoOOOOOOOOOOOOOOOOOo.X",
" .XoOoOoOoooooooooooooooOo.X",
" .XoOoOoOoooooooooooooooOo.X",
" .XoOOOoOoooooooooooooooOo.X",
" .XoooOoOoooooooooooooooOo.X",
" .XoooOOOoooooooooooooooOo.X",
" .XoooooOoooooooooooooooOo.X",
" .XoooooOOOOOOOOOOOOOOOOOo.X",
" .Xooooooooooooooooooooooo.X",
" ..........................X",
" XXXXXXXXXXXXXXXXXXXXXXXXXXX"};
