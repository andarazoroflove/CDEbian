/* XPM */
/* $XConsortium: Dtpixmp.t.pm /main/3 1995/07/18 16:47:30 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtpixmp_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 11 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X	s iconColor4	m white	c green",
"o    s iconGray1     m white c #dededededede",
"O	s iconColor6	m white	c yellow",
"+	s iconColor7	m white	c cyan",
"@	s iconColor1	m black	c black",
"#    s iconGray7     m black c #424242424242",
"$	s iconColor5	m black	c blue",
"%	s iconColor8	m black	c magenta",
"&	s iconColor3	m black	c red",
/* pixels */
"             ...",
" XXoOOo++o@@#...",
" XXoOOo++o@@#...",
" ooooooooooo#...",
" $$oXXoOOo++#...",
" $$oXXoOOo++#...",
" ooooooooooo#...",
" %%o$$oXXoOO#...",
" %%o$$oXXoOO#...",
" ooooooooooo#...",
" &&o%%o$$oXX#...",
" &&o%%o$$oXX#...",
" ooooooooooo#...",
" &&o&&o%%o$$#...",
" &&o&&o%%o$$#...",
" ######@@@@@@..."};
