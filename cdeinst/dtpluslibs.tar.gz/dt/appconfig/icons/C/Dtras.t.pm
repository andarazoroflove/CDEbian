/* XPM */
/* $XConsortium: Dtras.t.pm /main/3 1995/07/18 16:48:14 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Dtras_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".    s iconGray8     m black c #212121212121",
"X	s none	m none	c none",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O	s iconColor1	m black	c black",
"+    s iconGray1     m white c #dededededede",
/* pixels */
"            .XXX",
" ooooooooooo.XXX",
" ooooooooooo.XXX",
" ooooooooooo.XXX",
" oooooOooooo.XXX",
" ooooOOOoooo.XXX",
" oooO+O+Oooo.XXX",
" ooOOO+++Ooo.XXX",
" oO+O+O+OOOo.XXX",
" OOO+OOO+O+O.XXX",
" oO+++O+++Oo.XXX",
" ooOOO+O+Ooo.XXX",
" oooOOOOOooo.XXX",
" ooooO+Ooooo.XXX",
" oooooOooooo.XXX",
".............XXX"};
