/* XPM */
/* $XConsortium: Dtmanpg.m.pm /main/3 1995/07/18 16:44:25 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtmanpg_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 5 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XX oo oOOXXXXXXXX  o XXo.......",
" XX    XXXXXXXXXXX o oXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXooXXooOoXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoooXooOXXoOOooXooOOXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoOOXOooXoOOoXXOOXoXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoOOooOoXOooXooOOoooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooXoOXOOooXOOOOXooXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XX  o OOXXXXXXXXXXXXXXXo.......",
" XX    XXXXXXXXXXXXXXXXXo.......",
" XXoOOOXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOXOOoXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoo OoXoXXXXXXXXXXXXXXo.......",
" XX    XXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
