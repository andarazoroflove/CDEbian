/* XPM */
/* $XConsortium: DtMdl.l.pm /main/3 1995/07/18 16:22:03 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtMdl_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray5     m black c #737373737373",
"O	s iconColor3	m black	c red",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s iconGray4     m white c #949494949494",
"#	s iconColor4	m white	c green",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"...................      .......................",
".XXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXo      .XXXXXOOXXXOOXX+..+Xo",
".XX@@@XX@@@@XXXXXXXXXo      .XXXXXXOOOXXOX.#+.Xo",
".XXXXXXXXXXXXXXXXXXXXXo      .XXXOOXXOXXOX++#+Xo",
".XXXXXXXXXXXXXXXXXXXXXo      .XXXXXOOXOOXX.#+.Xo",
".XX@@X@@@@@XXXXXXXXXXXXo      .XXXXXXXXXXX+..+Xo",
".XXXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXX@@@@@X@@@o      .@@XX@@@XXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXX@@@X@@@@o      .@@@XX@@@@XXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXX@@@@@XX@@Xo      .@@@@@XXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXo      .XXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXo    .XXXXXXXXXXXXXXXXXXXo",
".XXXXXXXXXXXXXXXXXXXXXo    .XXXXXXXXXXXXXXXXXXXo",
".oooooooooooooooooooooo    ooooooooooooooooooooo"};
