/* XPM */
/* $XConsortium: Fptrsh6.l.pm /main/3 1995/07/18 17:07:18 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Ftrash6 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray7     m black c #424242424242",
"O    s bottomShadowColor m black c #636363636363",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray6     m black c #636363636363",
"#    s iconGray5     m black c #737373737373",
"$	s iconColor2	m white	c white",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray3     m white c #adadadadadad",
"*    s topShadowColor m white c #bdbdbdbdbdbd",
"=	s iconColor1	m black	c black",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                 .................              ",
"                ..XXXXXXXXXXXXXXXXo             ",
"               .XX.XXXXXXXXXXXXXXX.O            ",
"              .XXX+++++++++++++++++             ",
"             .XXX+@+@@+@+@+@++++++              ",
"             .XX+@o@oo@o@o@o@++++               ",
"              X+oo@o@@o@o@o@o+++                ",
"              O++++######++##+++                ",
"              OXo###$$$$$$X$$$$$%OO             ",
"              O&&ooooo$$X$X$oo$$$%%OO           ",
"              O&&XXXXXX$$X$o#XXXXXXX*           ",
"              O%&X%%%%%%$$o@%%%%%%%o*           ",
"              O%&X%%%%%%oo@#%%%%%%%o*           ",
"              O&&X%%%%%%%@@#%%%%%%%o*           ",
"              O%&X%%%%%%%%##%%%%%%%o*           ",
"              O&&X%%%%%%%%#%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%%%%%%%%%%%%%o*           ",
"              O&&X%%%%%%%%%%%%%%%%%o*           ",
"              O%&X%%%%%======%%%%%%o*           ",
"              *=&X%%%%%=......#%%%%o*           ",
"               *=X%%%%%======##%%%%o*           ",
"                *===================*           ",
"                 *******     ********           ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
