/* XPM */
/* $XConsortium: DthonFP.t.pm /main/3 1995/07/18 16:40:25 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard. */
static char *helponFP16[]={
/* width height ncolors cpp [x_hot y_hot] */
"16 16 21 1 0 0",
/* colors */
"  c none m none s none",
"/    s topShadowColor m white c #bdbdbdbdbdbd",
"=    s background    m black c #949494949494",
";    s selectColor m white c #737373737373",
"\    s bottomShadowColor m black c #636363636363",
"x s iconColor1 c black     m black",
". s iconColor2 c white     m white",
"r s iconColor3 c red       m black",
"g s iconColor4 c green     m white",
"b s iconColor5 c blue      m black",
"y s iconColor6 c yellow    m black",
"c s iconColor7 c cyan      m white",
"m s iconColor8 c magenta   m white",
"1    s iconGray1     m white c #dededededede",
"2    s iconGray2     m white c #bdbdbdbdbdbd",
"3    s iconGray3     m white c #adadadadadad",
"4    s iconGray4     m white c #949494949494",
"5    s iconGray5     m black c #737373737373",
"6    s iconGray6     m black c #636363636363",
"7    s iconGray7     m black c #424242424242",
"8    s iconGray8     m black c #212121212121",
/* pixels */
"        22222   ",
"       2444447  ",
"      264...467 ",
"     x244.4.447 ",
"     x26464.467 ",
"     x2464.4647 ",
"     x266666667 ",
"     xx266.667  ",
"  x xxxx77777   ",
"  x xxxxxx22    ",
"  xxxxx   /=    ",
"  xxx     /=    ",
"  xxxxx   /=    ",
"222222;;;;=22222",
"=r=y==;==;=/=4==",
"\\\\\\\\\\\\\\\\"
};
