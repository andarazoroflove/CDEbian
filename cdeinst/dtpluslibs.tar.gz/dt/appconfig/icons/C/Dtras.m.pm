/* XPM */
/* $XConsortium: Dtras.m.pm /main/3 1995/07/18 16:48:06 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtras_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".    s iconGray8     m black c #212121212121",
"X	s none	m none	c none",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O	s iconColor1	m black	c black",
"+    s iconGray1     m white c #dededededede",
/* pixels */
"                        .XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" oooooooooooOooooooooooo.XXXXXXX",
" ooooooooooOOOoooooooooo.XXXXXXX",
" oooooooooOOOOOooooooooo.XXXXXXX",
" ooooooooO+OOO+Ooooooooo.XXXXXXX",
" oooooooO+++O+++Oooooooo.XXXXXXX",
" ooooooOOO+O+O+O+Ooooooo.XXXXXXX",
" oooooOOOOO+++O+++Oooooo.XXXXXXX",
" ooooO+OOOOO+OOO+O+Ooooo.XXXXXXX",
" oooO+++OOOOOOOOO+++Oooo.XXXXXXX",
" ooOOO+O+OOO+OOOOO+OOOoo.XXXXXXX",
" oOOOOO+++O+++OOOOOOOOOo.XXXXXXX",
" ooOOO+O+OOO+O+OOO+OOOoo.XXXXXXX",
" oooO+++OOOOO+++O+++Oooo.XXXXXXX",
" ooooO+O+OOO+O+OOO+Ooooo.XXXXXXX",
" oooooO+++O+++OOOOOooooo.XXXXXXX",
" ooooooO+OOO+OOOOOoooooo.XXXXXXX",
" oooooooOOOOOOOOOooooooo.XXXXXXX",
" ooooooooOOO+OOOoooooooo.XXXXXXX",
" oooooooooO+++Oooooooooo.XXXXXXX",
" ooooooooooO+Ooooooooooo.XXXXXXX",
" oooooooooooOooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ooooooooooooooooooooooo.XXXXXXX",
" ........................XXXXXXX"};
