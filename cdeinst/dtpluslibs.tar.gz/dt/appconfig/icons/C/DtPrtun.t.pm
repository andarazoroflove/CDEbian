/* XPM */
/* $XConsortium: DtPrtun.t.pm /main/3 1995/07/18 16:25:37 drk $ */
static char * DtPrtun_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray8     m black c #212121212121",
"X	s iconColor6	m white	c yellow",
"o    s bottomShadowColor m black c #636363636363",
"O	s iconColor2	m white	c white",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#	s iconColor1	m black	c black",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray1     m white c #dededededede",
"&    s iconGray4     m white c #949494949494",
"*    s iconGray6     m black c #636363636363",
"=    s iconGray5     m black c #737373737373",
/* pixels */
"      .....     ",
"     .XXXXX.    ",
"    .XXXXXXX.   ",
"   o.XX.o.XX.   ",
"   oO..++.XX.   ",
"  ooOOO..XXXoo  ",
"oo@.OO.XXXX.#@. ",
"oO@####XX.##.@@#",
"oO$$$$.XX.%%%%%#",
"oO@@@@....%+++%#",
"oO%%%%.XX.%%++%#",
"oO%%%%.XX.%%%%%#",
"oO%%%%....%%%%%#",
"o&*.========####",
"  ############# ",
"  ..........o   "};
