/* XPM */
/* $XConsortium: IcMcomp.l.pm /main/3 1995/07/18 17:13:20 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * IcMcomp_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray6     m black c #636363636363",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor1	m black	c black",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray2     m white c #bdbdbdbdbdbd",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray4     m white c #949494949494",
"&	s iconColor6	m white	c yellow",
"*	s iconColor3	m black	c red",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"            ........................            ",
"            .XXXXXXXXXXXXXXXXXXXXXXo            ",
"            .XXXXXXXXXXXXXXXXXXXXXXo            ",
"            .XOOOXOOXOOOOXOOXOOXOOXo            ",
"            .XXXXXXXXXXXXXXXXXXXXXXo            ",
"            .XOO++O@XXXXXXXXXXXXXXXo            ",
"            .XXXoOXX@XXXXXXXXXXXXXXo            ",
"            .XXXO##XX@XXXXXXXXXXXXXo            ",
"            .XXXO$$%&X@XXXXXXXXXXXXo            ",
"            .XXX#@&O&&X@XXXXXXXXXXXo            ",
"            .XXXX$@&O&&X@XXXXXXXXXXo            ",
"            .XXXX$$@&O&&X@XXXXXXXXXo            ",
"            .XXXXX$$@&O&&X@XXXXXXXXo            ",
"            .XXXXXX$$@&O&&X@XXXXXXXo            ",
"            .XXXXXXX$$@&O&&X@XXXXXXo            ",
"            .XXXXXXX$$$@&O&&X@XXXXXo            ",
"          ...XXXXXXXX$$$@&O&&X@XXXXooo          ",
"        ..%%.XXXXXXXXX$$$@&O&&X@XXXoo%oo        ",
"      ..%%%%.XXXXXXXXXX$$$@&O&&X@XXoo%%%oo      ",
"     .oooooo.XXXXXXXXXX$$$$@&O&.$@Xo@oooo.o     ",
"     .Xoo###.XXXXXXXXXXX$$$$@&.XX$@oo##..Xo     ",
"     .XXXoo#.XXXXXXXXXXXX$$$$@%$X.$oo..XXXo     ",
"     .XXXXXooXXXXXXXXXXXXX$$$$@%.**$oXXXXXo     ",
"     .XXXXXXXooXXXXXXXXXXX$$$$$@*%**$oXXXXo     ",
"     .XXXXXXXXXooXXXXXXXXXX$$%%.@*%*oXXXXXo     ",
"     .XXXXXXXXXXXooXXXXXXXX%%..$$@*oXXXXXXo     ",
"     .XXXXXXXXXXXXXooXXXXX%..$$$$$@XXXXXXXo     ",
"     .XXXXXXXXXXXXXXXooXX..XX$$$$XXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXXooXXXXX$$XXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXooXXooXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXooXXXXXXooXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXooXXXXXXXXXXooXXXXXXXXXXXo     ",
"     .XXXXXXXXXooXXXXXXXXXXXXXXooXXXXXXXXXo     ",
"     .XXXXXXXooXXXXXXXXXXXXXXXXXXooXXXXXXXo     ",
"     .XXXXXooXXXXXXXXXXXXXXXXXXXXXXooXXXXXo     ",
"     .XXXooXXXXXXXXXXXXXXXXXXXXXXXXXXooXXXo     ",
"     .XooXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXooXo     ",
"     .ooooooooooooooooooooooooooooooooooooo     ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
