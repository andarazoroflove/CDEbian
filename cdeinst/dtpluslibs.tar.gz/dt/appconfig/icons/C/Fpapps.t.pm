/* XPM */
/* $XConsortium: Fpapps.t.pm /main/3 1995/07/18 16:55:10 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Novell, Inc.
**********************************************************************/
static char * *Fpapps [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 15 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray7     m black c #424242424242",
"o    s iconGray3     m white c #adadadadadad",
"O    s iconGray8     m black c #212121212121",
"+	s iconColor8	m black	c magenta",
"@    s iconGray5     m black c #737373737373",
"#	s iconColor1	m black	c black",
"$    s bottomShadowColor m black c #636363636363",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"&    s iconGray6     m black c #636363636363",
"*	s iconColor6	m white	c yellow",
"=	s iconColor7	m white	c cyan",
"-	s iconColor2	m white	c white",
";    s selectColor m white c #737373737373",
/* pixels */
"                ",
"   ..X oooO   + ",
"   @.X #XXO  .X ",
" $$..X$%&%O$*X  ",
" $$@.X$%%&O*X   ",
" $............  ",
" $.ooooooooooo  ",
" $.ooo=*=*-ooo; ",
" $.oooOOOO-ooo$;",
" $.ooo-----ooo$;",
" $.ooooooooooo$;",
" $.ooooooooooo$;",
" $.ooooooooooo$;",
"  .ooooooooooo$;",
"  .$$$$$$$$$$$$;",
"    ;;;;;;;;;;;;"};
