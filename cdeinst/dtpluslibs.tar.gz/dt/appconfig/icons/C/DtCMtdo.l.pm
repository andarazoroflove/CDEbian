/* XPM */
/* $XConsortium: DtCMtdo.l.pm /main/3 1995/07/18 16:19:57 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMtdo_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray7     m black c #424242424242",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor5	m black	c blue",
"@    s iconGray4     m white c #949494949494",
"#	s iconColor3	m black	c red",
"$    s iconGray3     m white c #adadadadadad",
"%    s iconGray1     m white c #dededededede",
"&	s iconColor6	m white	c yellow",
"*	s iconColor1	m black	c black",
/* pixels */
"     ....................................       ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXOOOOOXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXOXXX.X++@XXXX@XX@XXXXXXXXXXXXXXXo       ",
"     .XX++XX.++@@@@X@@@@XX@@@@@XXXXXXXXXo       ",
"     .X++++X++X@XXXXXX@XXXXXXXXXXXXXXXXXo       ",
"     .XX+++++XXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXX+++XXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXXX+XXXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXOOOOOXXXXXXXXXXXXXXXXXXXXXXXXXXXo       ",
"     .XXOXXX.XXX@XXXXX@XX@XXXX@XX+XXXXXXo       ",
"     .XXOXXX.X@@@@XX@@@@@@@X@@@++XXXXXXXo       ",
"     .XXOXXX.XXXXXX+X@XX@XXXX@++XXXXXXXXo       ",
"     .XXO....XXXXX++XXXXXXXXX++XXXXXXXXXo       ",
"     .XXXXXXXXXXX+++XXXXXXX+++XXXXXXXXXXo       ",
"     .XXXXXXXXXX+++++XXXXX+++XXXXXXXXXXXo       ",
"     .XXXXXXXXX++++++XXXX+++XXXXXXXXXXXXo       ",
"     .XXXXXXXX++++++++X++++XXXXXXXXXXXXXo       ",
"     .XXOOOOOXX+++++++++++XXXXXXXXXXXXXXo @     ",
"     .XXOXXX.XXX+++++++++XXXXX@XXXXXXXXXo@#$    ",
"     .XXOXXX.X@@@+++++++@@@X@@@XXXXXXXXX@#$#O   ",
"     .XXOXXX.XX@XX+++++XXX@X@XXXXXXXXXX@.O#O#O  ",
"     .XXO....XXXXXX+++XXXXXXXXXXXXXXXX@.%%O#O   ",
"     .XXXXXXXXXXXXXX+XXXXXXXXXXXXXXXX@.O%XXO    ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX@.&@OXO     ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXX@.&@&@O      ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXX@.&@&@O       ",
"     .XXOOOOOXXXXXXXXXXXXXXXXXXXX@.&@&@Oo       ",
"     .XXOXXX.XX@XX@XXXXX@XXXX@X@@.&@&@O@o       ",
"     .XXOXXX.X@@@@@@@X@@@@X@@@@@.&@&@O@$o       ",
"     .XXOXXX.X@XX@XXXXX@XXXX@X@.&@&@O@$Xo       ",
"     .XXO....XXXXXXXXXXXXXXXX@.&@&@O@$XXo       ",
"     .XXXXXXXXXXXXXXXXXXXXXX@.&@&@O@$XXXo       ",
"     .XXXXXXXXXXXXXXXXXXXXX@.&@&@O@$XXXXo       ",
"     .XXXXXXXXXXXXXXXXXXXX@.&@&@O@$XXXXXo       ",
"     .XXXXXXXXXXXXXXXXXXX@.&@&@O@$XXXXXXo       ",
"     .XXXXXXXXXXXXXXXXXX@.&@&@O@$XXXXXXXo       ",
"     .XXXXXXXXXXXXXXXXX@.&@&@O@$XXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXX@.&@&@O@$XXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXO.&@&@O@$XXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXO%%&@O@$XXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXX**XXO@$XXXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXX**OO@$XXXXXXXXXXXXXo       ",
"     .XXXXXXXXXXXXXXXX@@@$XXXXXXXXXXXXXXo       ",
"     .ooooooooooooooooooooooooooooooooooo       "};
