/* XPM */
/* $XConsortium: DtdirR.t.pm /main/3 1995/07/18 16:34:48 drk $ */
static char * DtdirR_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor3	m black	c red",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                ",
"         ...... ",
"        .XXXXXXo",
" ooooooooXOXOXO+",
".............+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
" ++++++++++++++ ",
"                ",
"                "};
