/* XPM */
/* $XConsortium: Dthsrc.t.pm /main/3 1995/07/18 17:11:11 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dthsrc_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray6     m black c #636363636363",
"@	s iconColor6	m white	c yellow",
"#    s iconGray5     m black c #737373737373",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" XXoOXOOXO+Xo...",
" XXXX@@@@XXXo...",
" XXo@@@@@@+Xo...",
" XXX@@XX@@XXo...",
" XXo##X@@#+Xo...",
" XXXXX@@XXXXo...",
" XXoX#@@##XXo...",
" XXXXXXXXXXXo...",
" XXoXO@@#OXXo...",
" XXXXX@@XXXXo...",
" XXo+Xo+o+XXo...",
" XXXXXXXXXXXo...",
" oooooooooooo..."};
