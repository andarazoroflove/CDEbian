/* XPM */
/* $XConsortium: Dtlink.t.pm /main/3 1995/07/18 16:43:34 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtlink_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor1	m black	c black",
"@    s iconGray5     m black c #737373737373",
/* pixels */
"             ...",
" XXXXXoOOOOo+...",
" XXXXXoOoOOO+...",
" X@@XooOooOo+...",
" XXXXOOOOoOo+...",
" X@X@OoOOOOo+...",
" XoooOooOooo+...",
" XoOOOOoOoXX+...",
" XoOoOOOOoXX+...",
" ooOooOoXXXX+...",
" OOOOoOo@X@X+...",
" OoOOOOoXXXX+...",
" OooOooo@@XX+...",
" OOoOoXXXXXX+...",
" OOOOoXXXXXX+...",
" ++++++++++++..."};
