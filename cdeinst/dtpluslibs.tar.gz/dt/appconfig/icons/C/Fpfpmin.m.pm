/* XPM */
/* $XConsortium: Fpfpmin.m.pm /main/3 1995/07/18 16:57:23 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Ffpmin [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
"     s iconGray8     m black c #212121212121",
".    s iconGray7     m black c #424242424242",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
"@    s topShadowColor m white c #bdbdbdbdbdbd",
"#    s background    m black c #949494949494",
"$    s selectColor m white c #737373737373",
"%    s bottomShadowColor m black c #636363636363",
"&	s iconColor6	m white	c yellow",
"*	s iconColor5	m black	c blue",
"=    s iconGray1     m white c #dededededede",
/* pixels */
"                                ",
". . . . . . . . . . . . . . . . ",
" . . . . . . . . . . . . . . . .",
". . . . . . . . . . . . . . . . ",
"................................",
" . . . . . . . . . . . . . . . .",
"................................",
"X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.",
"................................",
".X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X",
"X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.X.",
"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
"XoXoXoXoXoXoXoXoXoXoXoXoXoXoXoXo",
"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
"oXoXoXoXoXoXoXoXoXoXoXoXoXoXoXoX",
"XoXoXoXoXoXoXoXoXoXoXoXoXoXoXoXo",
"oooooooooooooooooooooooooooooooo",
"OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOo",
"oooooooooooooooooooooooooooooooo",
"oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO",
"OoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOo",
"oOoOoOoOoOoOoOoOoOoOoO++++oOoOoO",
"OOOOOOOOOOOOOOOOOOOOOO@###OOOOOO",
"OoOoOoOoOoOoOoOoOoOoOo@#o#OoOoOo",
"OOOOOOOOOOOOOOOOOOOOOO@###OOOOOO",
"OOOOOOOOOOOOOOOOOOOOOO@#o#OOOOOO",
"OOOOOOOOOOOOOOOOOOOOOO@###OOOOOO",
"++++++++++++########++++++++++++",
"@##$##$######%%%#%%%###########%",
"@$#&$#*#$#$##########=#*#$#*#=#%",
"@############%%%#%%%###########%",
"%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"};
