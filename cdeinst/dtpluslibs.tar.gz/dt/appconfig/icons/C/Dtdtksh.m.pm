/* XPM */
/* $XConsortium: Dtdtksh.m.pm /main/3 1995/07/18 16:37:04 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtdtksh_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 10 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray4     m white c #949494949494",
"+    s background    m black c #949494949494",
"@	s iconColor6	m white	c yellow",
"#    s iconGray1     m white c #dededededede",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray3     m white c #adadadadadad",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXOOOXOOOXXXXXXXXo.......",
" XXXXXXOOOOOXOOOOOXXXXXXo.......",
" XXXXXOOXOOOXOOOXOOXXXXXo.......",
" XXXXOOOXOOOXOOOXOOOXXXXo.......",
" XXXOXOOXOOOXOOOXOOXOXXXo.......",
" XXOOXOOOXOOXOOXOOOXOOXXo.......",
" XXOOOXOOXOOXOOXOOXOOOXXo.......",
" XOOOOXOOO+   O   XOOOOXo.......",
" XOOOOOXO  @#@O@#@# OOOXo.......",
" XOXOOOX @O @#O @#O #XOXo.......",
" XOOXOOO #O #@O@#@O @#OXo.......",
" XXOOX O @O @#O @#O #O Xo.......",
" XX+O  O@ @O @O@#O #@O@ o.......",
" XXXO @#O@#O #O @O @O@#@o.......",
" XXX @#@O @O @O@#O #O @#@.......",
" XXX  @#@O @O O O #O @#@ .......",
" XXX O @#O@#O@O@O @O@#@O .......",
" XXX #O @#O O O O O@#@O #.......",
" XXXX #O @O@ @O @#O @O #$.......",
" XXXXX #O @O#OO #O @O #$o.......",
" XXXXXX  O %O%#%O% O #$%o.......",
" XXXXXXXX O%@#O @%O $$%%o.......",
" XXXXXXXXX O#@#@#O#$%%XXo.......",
" XXXXXXXX @#@#@#@#@#XXXXo.......",
" XXXXXXX @#@#@#@#@#@#XXXo.......",
" XXXXXXXX$$$$#@#$$$$$XXXo.......",
" XXXXXXXXX%%%%#$%%%%%%XXo.......",
" XXXXXXXXXXXXXX%%XXXXXXXo.......",
" oooooooooooooooooooooooo......."};
