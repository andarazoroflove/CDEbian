/* XPM */
/* $XConsortium: Fpindc.t.pm /main/3 1995/07/18 16:58:26 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Findc [] = {
/* width height ncolors cpp [x_hot y_hot] */
"9 18 1 1 0 0",
/* colors */
" 	s none	m none	c none",
/* pixels */
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         ",
"         "};
