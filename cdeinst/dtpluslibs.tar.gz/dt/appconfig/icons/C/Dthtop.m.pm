/* XPM */
/* $XConsortium: Dthtop.m.pm /main/3 1995/07/18 17:11:19 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dthtop_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray6     m black c #636363636363",
"O	s iconColor1	m black	c black",
"+    s iconGray7     m black c #424242424242",
"@	s iconColor6	m white	c yellow",
"#    s background    m black c #949494949494",
/* pixels */
"                        ........",
" XXXXXXXXXXXXXXXXXXXXXXo........",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XOOXXXXXXXXXXXXXXXXXXXoO.......",
" XO XXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXXOOXO++X++XOOXXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXXOOXXO+XOOX+OOXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXOOXO++OXOO+OOXXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXOOOXX@@@@XXOO++XoO.......",
" XXXXXXXXXX@@@@@@XXXXXXoO.......",
" XXXXXXO++X@@XX@@++XOXXoO.......",
" XOOXXXXXXXXXXX@@XXXXXXoO.......",
" XO XXXO++OXoX@@X++OOOXoO.......",
" XXXXXXXXXXXX@@XXXXXXXXoO.......",
" XXXXXXOOXOoX@@oX+XOOXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXXXXXXX@@XXXXXXXXoO.......",
" XXXXXXXOOXoo@@oX+X+OXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXO+++XOOOXX+++OXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXX+X++O+XO++OXOXXXoO.......",
" XOOXXXXXXXXXXXXXXXXXXXoO.......",
" XO XXXOOX+OXXXXXXXXXXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" XXXXXXXXXXXXXXXXXXXXXXoO.......",
" oooooooooooooooooooooooO.......",
"# OOOOOOOOOOOOOOOOOOOOOOO......."};
