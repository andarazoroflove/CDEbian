/* XPM */
/* $XConsortium: Fpprnt5.m.pm /main/3 1995/07/18 17:02:43 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt06 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s bottomShadowColor m black c #636363636363",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s topShadowColor m white c #bdbdbdbdbdbd",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray6     m black c #636363636363",
"*    s iconGray8     m black c #212121212121",
"=    s selectColor m white c #737373737373",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"         .........              ",
"       .............            ",
"     .................          ",
"    ...................         ",
"                                ",
"       XXXXXXXXXXXXX            ",
"    oooXXXXOXOXOXXOXooooooo+    ",
"   o.OX..O..OO..O...@@@OOOO#+   ",
"  o.O$OXXXXXXXXXXXXX%@@@OOOO#+  ",
" o.OO&$$$$$$$$$$$$$$$$.OOOOOO#+ ",
" o.XXXXXXXXXXXXXXXXXXXXXXXXXX#+ ",
" o.OXXXXXXXXXXXXXXXXXX&&&&&&O#+ ",
" o.OXXXXXXXXXXXXXXXXXX&$$$$&O#+ ",
" o.OO$$$$$$$$$$$$$$$$$&&&&&&O#+ ",
" o.OOOOOOOOOOOOOOOOOOOOOOOOOO#+ ",
" o.OOOOOOOOOOOOOOOOOOOOOOOOOO#+ ",
" o.OO******************OOOOOO#+ ",
" o.OO*X$$$$$$$$$$$$$$$*OOOOOO#+ ",
" o.**X@@@@@@@@@@@@@@@@@******#+ ",
"   @#%$$$$$$$$$$$$$$$$$####*+++ ",
"   @*&&&&&&&&&&&&&&&&&&*****+   ",
"   ++******************o=+++    ",
"     ooooooooooooooooooo=       ",
"      ===================       ",
"                                ",
"                                ",
"                                ",
"                                "};
