/* XPM */
/* $XConsortium: Fpclock.m.pm /main/3 1995/07/18 16:56:18 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fclock [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s topShadowColor m white c #bdbdbdbdbdbd",
"o    s background    m black c #949494949494",
"O	s iconColor2	m white	c white",
"+    s selectColor m white c #737373737373",
"@    s iconGray8     m black c #212121212121",
/* pixels */
"                                ",
"                                ",
"     ......................     ",
"    ..XXXXXXXXXXXXXXXXXXXX.X    ",
"   ..XoooooooooOOoooooooooX.X   ",
"  ..XooooooooooOOooooooooooX.X  ",
"  .XooooooO++++++++++Ooooooo@X  ",
"  .Xooooo++++++++++++++ooooo@X  ",
"  .Xoooo++++++++++++++++oooo@X  ",
"  .Xooo++++++++++++++++++ooo@X  ",
"  .XooO++++++++++++++++++Ooo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .XOO++++++++++++++++++++OO@X  ",
"  .XOO++++++++++++++++++++OO@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .Xoo++++++++++++++++++++oo@X  ",
"  .XooO++++++++++++++++++Ooo@X  ",
"  .Xooo++++++++++++++++++ooo@X  ",
"  .Xoooo++++++++++++++++oooo@X  ",
"  .Xooooo++++++++++++++ooooo@X  ",
"  .XooooooO++++++++++Ooooooo@X  ",
"  ..XooooooooooOOoooooooooo@XX  ",
"   X.XoooooooooOOooooooooo@XX   ",
"    X.@@@@@@@@@@@@@@@@@@@@XX    ",
"     XXXXXXXXXXXXXXXXXXXXXX     ",
"                                ",
"                                "};
