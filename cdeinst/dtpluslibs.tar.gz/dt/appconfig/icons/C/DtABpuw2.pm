/* XPM */
/* $XConsortium: DtABpuw2.pm /main/3 1995/07/18 16:15:22 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABpuw2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 4 1 0 0",
/* colors */
"     s iconGray2     m white c #bdbdbdbdbdbd",
".	s iconColor1	m black	c black",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray3     m white c #adadadadadad",
/* pixels */
"                           .",
" XXXXXXXXXXXXXXXXXXXXXXXXXX.",
" X........................X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.oooooooooooooooooooooo X.",
" X.o     .o     .o     .o X.",
" X.o oooo.o oooo.o oooo.o X.",
" X.o......o......o......o X.",
" X.                       X.",
" XXXXXXXXXXXXXXXXXXXXXXXXXX.",
"............................"};
