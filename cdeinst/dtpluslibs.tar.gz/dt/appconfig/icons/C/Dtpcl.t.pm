/* XPM */
/* $XConsortium: Dtpcl.t.pm /main/3 1995/07/18 16:46:41 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtpcl_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O	s iconColor5	m black	c blue",
"+    s iconGray4     m white c #949494949494",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" XXooXXoooXXo...",
" XXXXXXXXXXXo...",
" XXooooXooXXo...",
" XXXXXXXXXXXo...",
" XXOOOOOOOOOOOOO",
" XXO  OOO  O OOO",
" XXO O O OOO OOO",
" XXO  OO OOO OOO",
" XXO OOO OOO OOO",
" XXO OOOO  O   O",
" XXOOOOOOOOOOOOO",
" XXX+++++++++...",
" oooooooooooo..."};
