/* XPM */
/* $XConsortium: Dtasys.t.pm /main/3 1995/07/18 16:29:38 drk $ */
static char * Dtasys [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 5 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor1	m black	c black",
"o    s iconGray4     m white c #949494949494",
"O	s iconColor5	m black	c blue",
/* pixels */
"                ",
"                ",
" .............X ",
" .oOoOoOoOoOoOX ",
" .OoOoOoOoOoOoX ",
"....oOoOoOoO...X",
".oo.OoOoOoOo.ooX",
".oo..........ooX",
".ooooooooooooooX",
".ooooooooooooooX",
".ooooooooooooooX",
".ooooooooooooooX",
".ooooooooooooooX",
".ooooooooooooooX",
".ooooooooooooooX",
"XXXXXXXXXXXXXXXX"};
