/* XPM */
/* $XConsortium: DtABdrw2.pm /main/3 1995/07/18 16:13:02 drk $ */
static char * DtABdrw2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 10 1 0 0",
/* colors */
"     s iconGray5     m black c #737373737373",
".    s iconGray1     m white c #dededededede",
"X	s iconColor1	m black	c black",
"o	s iconColor6	m white	c yellow",
"O	s iconColor5	m black	c blue",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray3     m white c #adadadadadad",
"$    s iconGray2     m white c #bdbdbdbdbdbd",
"%	s iconColor3	m black	c red",
/* pixels */
"                            ",
" .......................... ",
" ........XXXXXXXXXX........ ",
" ........XooooooooX........ ",
" ........XooooooooX........ ",
" .....XXXXooooooooX........ ",
" ...XXO+OXXoooooooX........ ",
" ..X+O.O@O+XooooooX........ ",
" .#XO.O.O@OXooooooX..X..... ",
" .XO.O.O$O+OXoooooX.X%X.... ",
" .X+O.O$O@O+XoooooXX%.%X... ",
" .XO+O$O$O+OXoooooX%.%.%X.. ",
" ..XO+O+O+OXoooooX%.%.%.%X. ",
" ..X+O+O+O+XooooX%.%.%.%.%X ",
" ...XXO+OXXooooXXXXXXXXXXXX ",
" .....XXXXooooooooX........ ",
" ........XooooooooX........ ",
" ........XXXXXXXXXX........ ",
" .......................... ",
"                            "};
