/* XPM */
/* $XConsortium: DtABgrp.pm /main/3 1995/07/18 16:13:35 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * group_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 8 1 0 0",
/* colors */
" 	s iconColor1	m black	c black",
".    s iconGray3     m white c #adadadadadad",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor2	m white	c white",
"@    s iconGray1     m white c #dededededede",
"#    s iconGray6     m black c #636363636363",
/* pixels */
"  .  .  .  .  .  .  .  . .  ",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
".XXXXXXXXXXXXoooooooooooooX.",
" XXXX  XXXXXXo........... X ",
" XXX OO XXXXXo            X ",
".XX O++O@XXXXoX+++++++++o X.",
" XX O++O@XXXXoX+++++++++o X ",
" XXX@OO@XXXXXoX+++++++++o X ",
".XXXX@@XXXXXXoX+++++++++o X.",
" XXXXXXXXXXXXoX+++++++++o X ",
" XXXXXXXXXXXXoX+++++++++o X ",
".XXXXXXXXXXXXoX+++++++++o X.",
" X@@@@@@@@@@XoX+++++++++o X ",
" X@@@@@@@@@ XoX+++++++++o X ",
".X@@......# XoX+++++++++o X.",
" X@@......# XoX+++++++++o X ",
" X@@####### Xoooooooooooo X ",
".X@         Xo            X.",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
"  .  .  .  .  .  .  .  . .  "};
