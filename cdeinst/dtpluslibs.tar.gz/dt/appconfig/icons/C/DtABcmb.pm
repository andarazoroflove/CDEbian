/* XPM */
/* $XConsortium: DtABcmb.pm /main/3 1995/07/18 16:12:54 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * combobox_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 7 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".    s iconGray1     m white c #dededededede",
"X    s iconGray3     m white c #adadadadadad",
"o	s iconColor1	m black	c black",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                            ",
"                            ",
"                            ",
"                            ",
" .......................... ",
" .XXXXXXXXXXXXoOXXXXXXXXXXo ",
" .XXXXXXXXXXXXoOXXXXXXXXXXo ",
" .XXXXXXXXXXXXoOX+OOOOOOO+o ",
" .XXXXXXXXXXXXoOXX+o@@@o+Xo ",
" .XXXXXXXXXXXXoOXXX+o@o+XXo ",
" .XXXXXXXXXXXXoOXXXX+o+XXXo ",
" .XXXXXXXXXXXXoOXXXXX+XXXXo ",
" .XXXXXXXXXXXXoOXXXXXXXXXXo ",
" .ooooooooooooooooooooooooo ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            "};
