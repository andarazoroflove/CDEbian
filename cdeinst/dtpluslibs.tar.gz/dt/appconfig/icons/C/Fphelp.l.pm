/* XPM */
/* $XConsortium: Fphelp.l.pm /main/3 1995/07/18 16:57:41 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * helpmgr [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 16 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray5     m black c #737373737373",
"o    s iconGray3     m white c #adadadadadad",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray7     m black c #424242424242",
"#    s topShadowColor m white c #bdbdbdbdbdbd",
"$    s iconGray6     m black c #636363636363",
"%	s iconColor7	m white	c cyan",
"&    s iconGray8     m black c #212121212121",
"*	s iconColor3	m black	c red",
"=    s selectColor m white c #737373737373",
"-    s iconGray1     m white c #dededededede",
";	s iconColor5	m black	c blue",
":	s iconColor2	m white	c white",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"           .........                            ",
"           .XoO++X@#                            ",
"           .$o%o%@@.........      $OOooooX&     ",
"     ......&$%+%X*@&++++++$@.....&$o++++X$&=    ",
"     .---Oo&$X%X*@@&+X$XXX$@&o;o;&$OXO+o+X&==   ",
"     .-Oo+X&$%+%X*@&+XXXXX$@&;o@$&$oX++XX@&=    ",
"     .-Oo+X&$X%X*@@&+XXXXX$@&@$X;&$OXo+XXX&==   ",
"     .-+X$X&$%+%X*@&+XXXXX$@&;o@$&$oX++XXX&=    ",
"     .-+X$X&$X%X*@@&:::::::@&@$@;&$OX+@XXX&==   ",
"     .-Oo+X&$%@%&*@:::::::::&;o@$&$oX++XXX&=    ",
"     .-+X$X&$X%&*@::::@@@::::@$@;&$OX+$XXX&==   ",
"     .-+o$X&$%+%X*:::@@XXX:::@o@$&$oX+@XXX&=    ",
"     .-Oo+X&$X%X*@:::@XXXX:::@$@;&$OX+$XXX&==   ",
"     .-+X$X&$%+%X*:::@XXXX:::@o@$&$oX+@XXX&=    ",
"     .-Oo+X&$X%&*@@&@XXXX::::@$X;&$OX+$XXX&==   ",
"     .-+X$X&$%@%&*@&+XXX::::&;o@$&$oX++XXX&=    ",
"     .-+o+X&$X%X*@@&+XX::::@&@$X;&$OX++XXX&==   ",
"     .-+X$X&$%@%&*@&+X::::$@&;o@$&$oX+$XXX&=    ",
"     .-Oo+X&$X%&*@@&+X:::@@@&@$X;&$oX+XXXX&==   ",
"     .-Oo+X&$%+%X*@&+X:::@$@&;o@$&$oX++XXX&=    ",
"     .-Oo+X&$X%X*@@&+XX@@@$@&@$X;&$oX++XXX&==   ",
"     .-Oo+X&$%+%X*@&+X:::X$@&;o@$&$oX++XXX&=    ",
"     .-Oo+X&$X%X*@@&+$:::@$@&@$X;&$oX++XXX&==   ",
"     .-Oo+X&$%+%X*@&+X:::@$@&;o@$&$oX++XXX&=    ",
"     .-Oo+X&$X%X*@@&+$$@@@$@&@$X;&$oX+@XXX&==   ",
"     .-oX$X&$%+%X*@&+XXXXX$@&;o@$&$oX++XXX&=    ",
"     .-Oo+X&$X%X*@@&+$X@@@$@&@$X;&$oX++XXX&==   ",
"     .-Oo+X&$%+%X*@&+XXXXX$@&;o@$&$oX++XXX&=    ",
"     .-Oo+X&$X%X*@@&+XXXXX$@&@$X;&$o$++XXX&==   ",
"     .OOo+X&$%+%X*@&+XXXXX$@&;o@$&$oX++XXX&=    ",
"     .oo+XX&$XXX$$@&+$XX$@$@&@$@;&$o$XXX$$&==   ",
"     .&&&&&&&&&&&&&&&&&&&&&&&&&&&& o&&&&&&&=    ",
"     .##############################       ==   ",
"                                     =======    ",
"                                      = = = =   ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
