/* XPM */
/* $XConsortium: DtABtxp2.pm /main/3 1995/07/18 16:16:36 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * text_pane_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 7 1 0 0",
/* colors */
"     s iconGray2     m white c #bdbdbdbdbdbd",
".	s iconColor1	m black	c black",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor2	m white	c white",
"@    s iconGray3     m white c #adadadadadad",
/* pixels */
"                           .",
" XXXXXXXXXXXXXXXXXXXXXXXXXX.",
" X.....................oXOX.",
" X.++++++++++++++++++++oXOX.",
" X.++++++++++++++++++++oXOX.",
" X.+............+++++++oX@X.",
" X.++++++++++++++++++++oX@X.",
" X.+.......++++++++++++oX@X.",
" X.++++++++++++++++++++oX@X.",
" X.+..........+++++++++oX@X.",
" X.++++++++++++++++++++oX@X.",
" X.+.....++++++++++++++oX@X.",
" X.++++++++++++++++++++oXOX.",
" X.+...............++++oXOX.",
" X.++++++++++++++++++++oXOX.",
" X.oooooooooooooooooooooXOX.",
" XXXXXXXXXXXXXXXXXXXXXXXXXX.",
" XOOOO@@@@@@@@@@@@@@OOOOXXX.",
" XXXXXXXXXXXXXXXXXXXXXXXXXX.",
"............................"};
