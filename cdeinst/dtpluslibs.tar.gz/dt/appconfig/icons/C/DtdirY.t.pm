/* XPM */
/* $XConsortium: DtdirY.t.pm /main/3 1995/07/18 16:35:03 drk $ */
static char * DtdirY_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor6	m white	c yellow",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                ",
"         ...... ",
"        .XXXXXXo",
" ooooooooXOXOXO+",
".............+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
".@@@@@@@@@@@@+O+",
" ++++++++++++++ ",
"                ",
"                "};
