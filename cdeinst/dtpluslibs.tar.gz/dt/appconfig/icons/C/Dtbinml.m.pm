/* XPM */
/* $XConsortium: Dtbinml.m.pm /main/3 1995/07/18 16:31:16 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtbinml_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray4     m white c #949494949494",
"o	s iconColor1	m black	c black",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"            ....................",
" XXXXXXXXXXo....................",
" XX               ..............",
" XX OOOOOOOOOOOOOo..............",
" XX OOOOOOOOOOOOOo..............",
" XX OO                   .......",
" XX OO +++++++++++++++++o.......",
" XX OO +++o++o++o++o+o++o.......",
" XX OO ++o+o+o+o+o+o+o++o.......",
" XX OO ++o+o+o+o+o+o+o++o.......",
" XX OO ++o+o+o+o+o+o+o++o.......",
" XX OO +++o++o++o++o+o++o.......",
" XX OO +++++++++++++++++o.......",
" XX OO +++o++o++o+++o+++o.......",
" oo OO ++o+o+o+o+o+o+o++o.......",
"... OO ++o+o+o+o+o+o+o++o.......",
"... OO ++o+o+o+o+o+o+o++o.......",
"... OO +++o++o++o+++o+++o.......",
"... OO +++++++++++++++++o.......",
"... OO ++o+o+o++o++o+o++o.......",
"... OO ++o+o+o+o+o+o+o++o.......",
"... OO ++o+o+o+o+o+o+o++o.......",
"... OO ++o+o+o+o+o+o+o++o.......",
"... oo ++o+o+o++o++o+o++o.......",
"...... +++++++++++++++++o.......",
"...... +++o++o++o++o++++o.......",
"...... ++o+o+o+o+o+o++++o.......",
"...... ++o+o+o+o+o+o++++o.......",
"...... ++o+o+o+o+o+o++++o.......",
"...... +++o++o++o++o++++o.......",
"...... +++++++++++++++++o.......",
"...... oooooooooooooooooo......."};
