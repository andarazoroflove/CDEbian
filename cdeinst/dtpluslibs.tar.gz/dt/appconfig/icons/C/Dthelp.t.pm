/* XPM */
/* $XConsortium: Dthelp.t.pm /main/3 1995/07/18 16:38:50 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * help [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray3     m white c #adadadadadad",
"X    s iconGray8     m black c #212121212121",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+	s iconColor6	m white	c yellow",
"@	s iconColor2	m white	c white",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray6     m black c #636363636363",
"%    s iconGray7     m black c #424242424242",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"    ..X.o   o.X ",
"  O.oo+@+@#Xo$X ",
"  O$oo@##+#Xo$X ",
"  O$ooX#+@#X#$X ",
"  O$ooX.@X#Xo$X ",
"  O$ooX@+X#X#$X ",
"  O$ooX##X#Xo$X ",
"  O$ooX@+X#X%$X ",
"  O$ooX##X#Xo$X ",
"  .XXXXXXXXXXXX ",
"                ",
"                "};
