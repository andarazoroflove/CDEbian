/* XPM */
/* $XConsortium: DtBento.l.pm /main/3 1995/07/18 16:16:51 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtBento_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s iconGray3     m white c #adadadadadad",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor2	m white	c white",
"@    s iconGray1     m white c #dededededede",
"#	s iconColor4	m white	c green",
"$    s iconGray6     m black c #636363636363",
"%	s iconColor1	m black	c black",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"       ............................XXXXoo       ",
"       XXXXXooooooooooooooOOOOOOOOOOOOOOO       ",
"      ................................XXoo      ",
"      XXooooooooooooooOOOOOOOOOOOOOOOOOOOO      ",
"     +++++++++++++++++++++++++++++++++++++o     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.@.@@O     ",
"     +@OO@O@@@@@@@@@@@@@@@@@@@@OO@@OO#X#.@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@OO@.O#O@@O     ",
"     +@OOO@@@@@@@@@@@@@@@@@@@@@OO@@OOO#O.@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@OO@.#X#@@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.@O     ",
"     +@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.$O    ",
"   +O+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.@.@$oX   ",
"  +O$+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@...$%oX  ",
" +@.XXoooooo...@@@@@@@@@@@@@@@@@@@@@.OOOOOOOOOo ",
" +@.........oXX.@@@OO@OOOO@OO@@@@@@@O.........$ ",
" +@@.XXXXXXXO$X..@@@@@@@@@@@@@@@@@.O.XXXXXXoOO$ ",
" +@...XXXXXXO$XX.@@OOOOO@OOOO@@@@@@O.XXXXXoooO$ ",
" +@@.XXXXXXXO$X.X@@@@@@@@@@@@@@@.@.O.XXXXXXoOO$ ",
" +@...XXXXXXO$XX.X.................O.XXXXXoooO$ ",
" +@@.XXXXXXXXO$XXXXXXXXXXXXXXXXXXXO.XXXXXXXoOO$ ",
" +@...XXXXXXXXo$$$$$$$$$$$$$$$$$$$.XXXXXXXoooO$ ",
" +@@.XXXXXXXXXX...................XXXXXXXXXoOO$ ",
" +@...XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXoooO$ ",
" +@@.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXoOO$ ",
" +@...XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXoooO$ ",
" .XXooooooooooooooooooooooooooooooooooooooooOO$ ",
" XOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO ",
"                                                "};
