/* XPM */
/* $XConsortium: Dtassem.m.pm /main/3 1995/07/18 16:28:54 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtassem_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray1     m white c #dededededede",
"@	s iconColor5	m black	c blue",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray4     m white c #949494949494",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooXOXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooXXXXXXOXOOoXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoooOXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooooXoXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOOXoXXXXXoXoXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoooOXXXXXXOXOoXXXoXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooXXXXXXOOOXoXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXX++++++++++++.",
" XXXXXXXXXXXXXXXXXX+O@O@O@OO@Oo.",
" XXOOOXXXXXXXXXXXXX+@O@O  @@O@o.",
" XXXXXXXXXXXXXOOoXX+O@O O@ O@Oo.",
" XXOOOOXOXXXXXXXXXX+@O@ @O@@O@o.",
" XXXXXXXXXXXXXXXXXX+O@O@  OO@Oo.",
" XXOOXOXXXXXXXXXXXX+@O@O@O @O@o.",
" XXXXXXXXXXXXXXXXXX+O@O O@ O@Oo.",
" XXXXXXXXXXXXXXXXXX+@O@O  @@O@o.",
" XXOXOOXOXXXXXXXXXX+O@O@O@OO@Oo.",
" XXXXXXXXXXXXXXXXXX+oooooooooo#.",
" XXXXXXXXXXXXXXXXXXX$$$$$.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
