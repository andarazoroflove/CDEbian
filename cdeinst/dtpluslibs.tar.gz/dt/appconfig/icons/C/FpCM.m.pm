/* XPM */
/* $XConsortium: FpCM.m.pm /main/3 1995/07/18 16:54:21 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * FpCM_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s bottomShadowColor m black c #636363636363",
"o	s iconColor2	m white	c white",
"O    s iconGray3     m white c #adadadadadad",
"+    s topShadowColor m white c #bdbdbdbdbdbd",
"@    s iconGray6     m black c #636363636363",
"#    s iconGray2     m white c #bdbdbdbdbdbd",
"$    s iconGray7     m black c #424242424242",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray5     m black c #737373737373",
"*	s iconColor1	m black	c black",
/* pixels */
"      .                 .       ",
"  XXX.oOXXXXXXXXXXXXXXX.oOXXX+  ",
"  X...oO@...............oO@#$+  ",
"  X.#Oo%o##############Oo%%&$+  ",
"  X.#Oo%&##############O.%%&$+  ",
"  X.#*%*###############*%*#&$+  ",
"  X.##*#################*##&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.#######################&$+  ",
"  X.##################oo..&&$+  ",
"  X.##################o.O&@&$+  ",
"  X.##################.O&@#&$+  ",
"  X.##################.&@##&$+  ",
"  X.##################&@###&$+  ",
"  X.&&&&&&&&&&&&&&&&&&&&&&&$$+  ",
"  X$$$$$$$$$$$$$$$$$$$$$$$$$$+  ",
"  ++++++++++++++++++++++++++++  "};
