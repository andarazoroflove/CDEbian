/* XPM */
/* $XConsortium: Dtlink.m.pm /main/3 1995/07/18 16:43:26 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtlink_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor1	m black	c black",
"@    s iconGray5     m black c #737373737373",
"#    s iconGray7     m black c #424242424242",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXoOOOOoO+.......",
" XXXXXXXXXXXXXXXXoOoOOOO+.......",
" XXXXXXXXXXXXXXoooOooOoo+.......",
" XXXXXXXXXXXXXXoOOOOoOoX+.......",
" XXX@@X+##XXX#XoOoOOOOoX+.......",
" XXXXXXXXXXXXoooOooOoooX+.......",
" XXXXXXXXXXXXoOOOOoOoXXX+.......",
" XXX@+XX+@#X#oOoOOOOoXXX+.......",
" XXXXXXXXXXoooOooOoooXXX+.......",
" XX+@X+##X#oOOOOoOo+XXXX+.......",
" XXXXXXXXXXoOoOOOOoXXXXX+.......",
" XX@@@X@+oooOooOooo+##XX+.......",
" XXXXXXXXoOOOOoOoXXXXXXX+.......",
" XX+##X@@oOoOOOOo#@X+XXX+.......",
" XXXXXXoooOooOoooXXXXXXX+.......",
" XX@##XoOOOOoOo@@##@@+XX+.......",
" XXXXXXoOoOOOOoXXXXXXXXX+.......",
" XX+@oooOooOooo###X++XXX+.......",
" XXXXoOOOOoOoXXXXXXXXXXX+.......",
" XXXXoOoOOOOoXXXXXXXXXXX+.......",
" XXoooOooOoooX+XX#X#+XXX+.......",
" XXoOOOOoOoXXXXXXXXXXXXX+.......",
" XXoOoOOOOoX@@@XX###+XXX+.......",
" oooOooOoooXXXXXXXXXXXXX+.......",
" oOOOOoOo#X##X@@#+X+XXXX+.......",
" oOoOOOOoXXXXXXXXXXXXXXX+.......",
" oOooOooo@+XXXXXXXXXXXXX+.......",
" OOOoOoXXXXXXXXXXXXXXXXX+.......",
" oOOOOoXXXXXXXXXXXXXXXXX+.......",
" ooOoooXXXXXXXXXXXXXXXXX+.......",
" ++++++++++++++++++++++++......."};
