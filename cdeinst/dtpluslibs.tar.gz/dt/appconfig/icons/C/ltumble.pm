/* XPM */
/* $XConsortium: ltumble.pm /main/3 1996/08/12 18:44:01 cde-hp $ */
/*
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */

static char * ltumble [] = {
/* width height ncolors cpp [x_hot y_hot] */
"23 31 2 1 0 0",
/* colors */
" 	s iconColor1	m black	c black",
".	s iconColor2	m white	c white",
/* pixels */
"                       ",
" ..................... ",
" ..................... ",
" ..                 .. ",
" ..................... ",
" ..               .... ",
" ..................... ",
" ..................... ",
" ..               .... ",
" ..................... ",
" ..                ... ",
" ..................... ",
" ..       ............ ",
" ..................... ",
" ..................... ",
"                       ",
" ..................... ",
" ..................... ",
" ..               .... ",
" ..................... ",
" ..                ... ",
" ..................... ",
" ..       ............ ",
" ..................... ",
" ..................... ",
" ..               .... ",
" ..................... ",
" ..             ...... ",
" ..................... ",
" ..................... ",
"                       "};
