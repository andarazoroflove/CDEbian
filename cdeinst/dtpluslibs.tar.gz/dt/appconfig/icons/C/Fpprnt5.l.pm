/* XPM */
/* $XConsortium: Fpprnt5.l.pm /main/3 1995/07/18 17:02:35 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt06 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s bottomShadowColor m black c #636363636363",
"+    s iconGray3     m white c #adadadadadad",
"@    s iconGray7     m black c #424242424242",
"#    s topShadowColor m white c #bdbdbdbdbdbd",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray6     m black c #636363636363",
"*    s iconGray8     m black c #212121212121",
"=    s selectColor m white c #737373737373",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                ............                    ",
"              ................                  ",
"            ....................                ",
"          .......................               ",
"         .........................              ",
"                                                ",
"            XXXXXXXXXXXXXXXXXXX                 ",
"            XXXXXXXXXXXXXXXXXXX                 ",
"            XXoooooXooooooooXXX                 ",
"        OOOOXXXXoXoXXoXoXoXXXXXOOOOOOOOOO       ",
"       O.ooo..oooo.oooo.ooooo..+++++ooooo@#     ",
"      O.ooo+....................+.+++ooooo@#    ",
"     O.ooo$%XXXXXXXXXXXXXXXXXXXX%oX++oooooo@#   ",
"    O.ooo@&$$$$$$$$$$$$$$$$$$$$$$$.ooooooooo@#  ",
"    O.......................................*#  ",
"    O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*#  ",
"    O.ooXXXXXXXXXXXXXXXXXXXXXXXXXX&&&&&&&&&o*#  ",
"    O.ooX%%%oo%%%oo%%%oo%%%oo%%%XX&ooo$$$$&o*#  ",
"    O.ooXXXXXXXXXXXXXXXXXXXXXXXXXX&$$$$$$$&o*#  ",
"    O.ooo$$$$$$$$$$$$$$$$$$$$$$$$$&&&&&&&&&o*#  ",
"    O.oooooooooooooooooooooooooooooooooooooo*#  ",
"    O.oooooooooooooooooooooooooooooooooooooo*#  ",
"    O.oooooooooooooooooooooooooooooooooooooo*#  ",
"    O.ooo$$$$$$$$$$$$$$$$$$$$$$$$$$$oooooooo*#  ",
"    O.ooo$*************************ooooooooo*#  ",
"    O.ooo$*%$$$$$$$$$$$$$$$$$$$$$$**oooooooo*#  ",
"    O.****+.$$$$$$$$$$$$$$$$$$$$$$$**********#  ",
"    O#O+@*+++++++++++++++++++++++++*@@@@@@*###  ",
"      O+@*%$$$$$$$$$$$$$$$$$$$$$$$$*@@@@@@*#    ",
"      O+***********************************#    ",
"      O##*%$$$$$$$$$$$$$$$$$$$$$$$$*O ######    ",
"         ***************************O=          ",
"          OOOOOOOOOOOOOOOOOOOOOOOOOOO=          ",
"           ===========================          ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
