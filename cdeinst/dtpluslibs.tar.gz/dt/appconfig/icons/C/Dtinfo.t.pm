/* XPM */
/* $XConsortium: Dtinfo.t.pm /main/3 1996/07/23 12:14:36 drk $ */
static char * Dtinfo_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor5	m black	c blue",
"o	s iconGray5	m black	c #737373737373",
"O	s iconGray8	m black	c #212121212121",
"+	s iconGray4	m white	c #949494949494",
"@	s iconGray1	m white	c #dededededede",
"#	s iconGray7	m black	c #424242424242",
"$	s iconGray2	m white	c #bdbdbdbdbdbd",
"%	s iconGray6	m black	c #636363636363",
/* pixels */
"     ......     ",
"    .XoXoXoO    ",
"   .XoX..oXoO   ",
" +.XoXoXoXoXoO+ ",
"+@.oXoX..oXoXO@#",
"$@.XoX...XoXoO@#",
"$@.oXoX..oXoXO@#",
"$@.XoXo..XoXoO@#",
"$@.oXoX...XoXO@#",
"$@@OoXoXoXoXO@@#",
"$++@OoXoXoXO@+@#",
"$@@@@OOOOOO@@@@#",
"$++++@@+%@@+++@#",
"$@@@@@@+%@@@@@@#",
"$%%%%%%+%%%%%%%#",
"%OOOOOO%%OOOOOO%"};
