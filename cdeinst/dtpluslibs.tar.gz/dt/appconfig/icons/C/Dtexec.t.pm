/* XPM */
/* $XConsortium: Dtexec.t.pm /main/3 1995/07/18 16:37:27 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * execute [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray3     m white c #adadadadadad",
"o	s iconColor2	m white	c white",
"O    s iconGray8     m black c #212121212121",
"+    s iconGray7     m black c #424242424242",
"@	s iconColor6	m white	c yellow",
"#    s iconGray6     m black c #636363636363",
"$    s iconGray5     m black c #737373737373",
/* pixels */
" .............. ",
". X X X X X oOX+",
".X X X X X@@OX +",
". X X X X@oOX X+",
".X X X @o@OX X +",
". X X @o@o@o@ X+",
".X X X OO@o@OX +",
". X X X @o@OX X+",
".X X X @o@OX X +",
". X X @o@OX X X+",
".X X @o@o@o@oX +",
". X X OO@o@O# X+",
".X X X @o@O$ X +",
". X X @oO#$ X X+",
".X X @oO$X X X +",
" +++@++++++++++ "};
