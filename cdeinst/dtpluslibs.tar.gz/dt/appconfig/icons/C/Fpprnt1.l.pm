/* XPM */
/* $XConsortium: Fpprnt1.l.pm /main/3 1995/07/18 17:01:26 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fprnt02 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray1     m white c #dededededede",
"O    s bottomShadowColor m black c #636363636363",
"+    s iconGray7     m black c #424242424242",
"@    s topShadowColor m white c #bdbdbdbdbdbd",
"#    s iconGray3     m white c #adadadadadad",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray4     m white c #949494949494",
"&    s iconGray6     m black c #636363636363",
"*    s iconGray8     m black c #212121212121",
"=    s selectColor m white c #737373737373",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"              ...............                   ",
"              ...............                   ",
"             ..XXXXX.XXXXXXX..                  ",
"             ....X.X..X.X.X...                  ",
"            ...XXXX.XXXX.XXXX.o                 ",
"        OOOO...X...X..X.X.X....OOOOOOOOOO       ",
"       O.XXX..XXXXX.XXXX.X.X...ooXXXXXXXX+@     ",
"      O.XXX#....................#.XXXXXXXX+@    ",
"     O.XXX$%oooooooooooooooooooo%XoXXXXXXXX+@   ",
"    O.XXX+&$$$$$$$$$$$$$$$$$$$$$$$.XXXXXXXXX+@  ",
"    O.......................................*@  ",
"    O.oooooooooooooooooooooooooooooooooooooo*@  ",
"    O.XXoooooooooooooooooooooooooo&&&&&&&&&X*@  ",
"    O.XXo%%%XX%%%XX%%%XX%%%XX%%%oo&XXX$$$$&X*@  ",
"    O.XXoooooooooooooooooooooooooo&$$$$$$$&X*@  ",
"    O.XXX$$$$$$$$$$$$$$$$$$$$$$$$$&&&&&&&&&X*@  ",
"    O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*@  ",
"    O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*@  ",
"    O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX*@  ",
"    O.XXX$$$$$$$$$$$$$$$$$$$$$$$$$$$XXXXXXXX*@  ",
"    O.XXX$*************************XXXXXXXXX*@  ",
"    O.XXX$*%$$$$$$$$$$$$$$$$$$$$$$**XXXXXXXX*@  ",
"    O.****#.$$$$$$$$$$$$$$$$$$$$$$$**********@  ",
"    O@O#+*#########################*++++++*@@@  ",
"      O#+*%$$$$$$$$$$$$$$$$$$$$$$$$*++++++*@    ",
"      O#***********************************@    ",
"      O@@*%$$$$$$$$$$$$$$$$$$$$$$$$*O @@@@@@    ",
"         ***************************O=          ",
"          OOOOOOOOOOOOOOOOOOOOOOOOOOO=          ",
"           ===========================          ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
