/* XPM */
/* $XConsortium: Dtkey.m.pm /main/3 1995/07/18 16:42:52 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtkey_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 7 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray6     m black c #636363636363",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXooXoOOXXOO+++++++XXXo.......",
" XXXXXXXXXXXX++@@@@@++XXo.......",
" XXXXXXXXXXX++@@@+@@@++Xo.......",
" XXXooXXooOo+@@@+++@@@+Xo.......",
" XXXXXXXXXXX+@@@@+@@@@+Xo.......",
" XXooXoOOXoO+@@@@@@@@@+Xo.......",
" XXXXXXXXXXX+@@@@@@@@@+Xo.......",
" XXoooXooOXX+@@@@@@@@@+Xo.......",
" XXXXXXXXXXX+@@@@@@@@@+Xo.......",
" XXoOOXOooXo+X@@@@@@@X+Xo.......",
" XXXXXXXXXXXX+XX@@@XX+XXo.......",
" XXoOOooOoXOo++@@@@@++XXo.......",
" XXXXXXXXXXXX+++@@@++XXXo.......",
" XXooXoOXOOooX++@@@+XXXXo.......",
" XXXXXXXXXXXXXX+@@++XXXXo.......",
" XXXXXXXXXXXXXX+@@@+XXXXo.......",
" XXXooXOOXoooXX+@@@+XXXXo.......",
" XXXXXXXXXXXXXX+@@++XXXXo.......",
" XXoOOOXoOOXooX+@@@+XXXXo.......",
" XXXXXXXXXXXXXX+@@@+XXXXo.......",
" XXOXOOoOOXOOXX+@@++XXXXo.......",
" XXXXXXXXXXXXXX++@++XXXXo.......",
" XXooXOoXooXXXXX+++XXXXXo.......",
" XXXXXXXXXXXXXXXX+XXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
