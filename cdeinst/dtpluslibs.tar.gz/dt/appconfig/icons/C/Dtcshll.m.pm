/* XPM */
/* $XConsortium: Dtcshll.m.pm /main/3 1995/07/18 16:33:07 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtcshll_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray1     m white c #dededededede",
"@	s iconColor5	m black	c blue",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray3     m white c #adadadadadad",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXOOOXOOOXXXXXXXXo.......",
" XXXXXXOOOOOXOOOOOXXXXXXo.......",
" XXXXXOOXOOOXOOOXOOXXXXXo.......",
" XXXXOOOXOOOXOOOXOOOXXXXo.......",
" XXXOXOOXOOOXOOOXOOXOXXXo.......",
" XXOOXOOOXOOXOOXOOOXOOXXo.......",
" XXOOOXOOXOOXOOXOOXOOOXXo.......",
" XOOOOXOOXOOXOOXOOXOOOOXo.......",
" XOOOOOXOOXOXOXOOXOOOOOXo.......",
" XOXOOOXOOXOXOXOOXOOOXOXo.......",
" XOOXOOOXOXOXOXOXOOOXOOXo.......",
" XXOOXOOXOOOXOOOXOOXOOXXo.......",
" XXXOOXOOXOOXOOXOOXOOXXXo.......",
" XXXXOOXOXOXXXOXOXOO+++++++++++.",
" XXXXXXOXOOOXOOOXOXX+@#@#@#@#@o.",
" XXXXXXXOOOOOOOOOXXX+#@#   #@#o.",
" XXXXXXOOOOOOOOOOOXX+@# #@# #@o.",
" XXXXXOOOOOOOOOOOOOX+#@ @#@#@#o.",
" XXXXXXXXXXOOOXXXXXX+@# #@#@#@o.",
" XXXXXXXXXXXOXXXXXXX+#@ @#@#@#o.",
" XXXXXXXXXXXXXXXXXXX+@# #@# #@o.",
" XXXXXXXXXXXXXXXXXXX+#@#   #@#o.",
" XXXXXXXXXXXXXXXXXXX+@#@#@#@#@o.",
" XXXXXXXXXXXXXXXXXXX+oooooooooo.",
" XXXXXXXXXXXXXXXXXXXX$$$$.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
