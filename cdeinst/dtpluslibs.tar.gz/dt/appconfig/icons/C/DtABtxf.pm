/* XPM */
/* $XConsortium: DtABtxf.pm /main/3 1995/07/18 16:16:21 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABtxf_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray3     m white c #adadadadadad",
".	s iconColor1	m black	c black",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray1     m white c #dededededede",
/* pixels */
"                            ",
"              ............. ",
"              .XXXXXXXXXXXo ",
" .....        .XOXOXXXXXXXo ",
"   .       .  .XXOXXXXXXXXo ",
"   . . .  ..  .XXOXXXXXXXXo ",
"   .... .. .  .XXOXXXXXXXXo ",
"   ..   .. .  .XXOXXXXXXXXo ",
"   . . .  . . .XOXOXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .XXXXXXXXXXXo ",
"              .oooooooooooo ",
"                            "};
