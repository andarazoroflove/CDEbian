/* XPM */
/* $XConsortium: Dtcat.m.pm /main/3 1995/07/18 16:32:58 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtcat_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray1     m white c #dededededede",
"@	s iconColor5	m black	c blue",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray4     m white c #949494949494",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooXOXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooXXXXXXOXOOoXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoooOXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooooXoXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOOXoXXXXXoXoXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoooOXXXXXXOXOoXXXoXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOooXXXXXXOOOXoXXXXXXXo.......",
" XXXXXXXXXXXX+++++++++++++++++++",
" XXXXXXXXXXXX+O@O@O@O@O@O@O@O@Oo",
" XXXXXXXXXXXX+@O  @O@  O@     @o",
" XXOOOXXXXXXX+O O@ @ @O O@O O@Oo",
" XXXXXXXXXXXX+@ @O@O O@ @O@ @O@o",
" XXOOOOXOXXXX+O O@O@ @O O@O O@Oo",
" XXXXXXXXXXXX+@ @O@O    @O@ @O@o",
" XXOOXOXXXXXX+O O@ @ @O @@O O@Oo",
" XXXXXXXXXXXX+@O  @O O@ @O@ @O@o",
" XXOOOXOXXXXX+O@O@O@O@O@O@O@O@Oo",
" XXXXXXXXXXXX+ooooooooooooooooo#",
" XXXXXXXXXXXXX$$$$$$$$$$$.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
