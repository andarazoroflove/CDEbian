/* XPM */
/* $XConsortium: DtABsld.pm /main/3 1995/07/18 16:15:46 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABsld_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 6 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".	s iconColor1	m black	c black",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray6     m black c #636363636363",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
" .......................... ",
" .XXXXXooXooooooooOooXXXXX. ",
" .XXXoo+ Xo+++++++Oo+ooXXX. ",
" .Xoo+++ Xo+++++++Oo+++ooX. ",
" .o+++++ Xo+++++++Oo+++++ . ",
" .X  +++ Xo+++++++Oo+++  X. ",
" .XXX  + Xo+++++++Oo+  XXX. ",
" .XXXXX  XoOOOOOOOOo XXXXX. ",
" .......................... ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            ",
"                            "};
