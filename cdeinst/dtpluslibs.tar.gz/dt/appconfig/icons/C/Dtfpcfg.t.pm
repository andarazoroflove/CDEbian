/* XPM */
/* $XConsortium: Dtfpcfg.t.pm /main/3 1995/07/18 16:37:43 drk $ */
static char * Dtfpcfg_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 11 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s background    m black c #949494949494",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray7     m black c #424242424242",
"+	s iconColor5	m black	c blue",
"@    s iconGray4     m white c #949494949494",
"#	s iconColor6	m white	c yellow",
"$	s iconColor3	m black	c red",
"%	s iconColor1	m black	c black",
"&    s bottomShadowColor m black c #636363636363",
/* pixels */
"                ",
"                ",
"                ",
"        .....   ",
"       .        ",
"   .......   .  ",
"   .  .  .   .  ",
"   . ...... ... ",
"      .  .   .  ",
"XXXXXXXXXXoXXXXX",
"OX+@XO#XO$oXXXXX",
"@XO@XOOXOOoXOOO%",
"&&&&&&&&&&&&&&&&",
"             .  ",
"            ... ",
"             .  "};
