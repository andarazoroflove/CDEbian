/* XPM */
/* $XConsortium: DtMail.t.pm /main/3 1995/07/18 16:21:56 drk $ */
static char * DtMail_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray6     m black c #636363636363",
"o	s iconColor2	m white	c white",
"O    s iconGray5     m black c #737373737373",
"+	s iconColor3	m black	c red",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray3     m white c #adadadadadad",
"$    s iconGray4     m white c #949494949494",
"%    s iconGray7     m black c #424242424242",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"   ..........   ",
"  XXXXXXXXXXXX  ",
" oooooooooooooO ",
" o............O ",
" o.OO.....+++.O ",
" o............O ",
"oooo..OOOO......",
"o.@#X......o$$X%",
"o.@#$oooooo$$$X%",
"o.@#$$$$$$$$$$X%",
"o.@#$$$$$$$$$$X%",
"XXXXXXXXXXXXXXX%"};
