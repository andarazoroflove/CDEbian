/* XPM */
/* $XConsortium: Fpstyle.s.pm /main/3 1995/07/18 17:05:00 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fstyle [] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 17 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O	s iconColor8	m black	c magenta",
"+	s iconColor6	m white	c yellow",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray3     m white c #adadadadadad",
"$    s topShadowColor m white c #bdbdbdbdbdbd",
"%	s iconColor1	m black	c black",
"&	s iconColor3	m black	c red",
"*    s iconGray4     m white c #949494949494",
"=    s background    m black c #949494949494",
"-	s iconColor5	m black	c blue",
";	s iconColor4	m white	c green",
":    s iconGray5     m black c #737373737373",
"?    s iconGray6     m black c #636363636363",
/* pixels */
"                        ",
"                        ",
"                        ",
"                        ",
"                        ",
"         .........      ",
"       ..XXXXXXXXX..    ",
"     ..XXoooooOOoXXX.   ",
"    .XXo++oooOOO@oo#X$  ",
"   .XXo++++oo@@@@ooo%$  ",
"  .XXoo+++&oooooooo%%$  ",
"  .Xoooo&&&o*%%%oo%%$   ",
" .XXoooooooo%##Xo%%$..  ",
" .Xo&&&&oooo%%%Xo%=XX%$ ",
" .Xoo&&%ooooooooooooo%$ ",
" .Xoo&%oo---oo;-;;oo%$$ ",
" .X:oooo---%o;-;@@o%$$  ",
"  $%%#ooo-%%o--@oo%$$   ",
"   $$%%?oooooooo@%$$    ",
"     $$%%%%%%%%%$$$     ",
"       $$$$$$$$$$       ",
"                        ",
"                        ",
"                        "};
