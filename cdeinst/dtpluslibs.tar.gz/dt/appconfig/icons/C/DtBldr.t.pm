/* XPM */
/* $XConsortium: DtBldr.t.pm /main/3 1995/07/18 16:17:46 drk $ */
static char * DtaBldr2_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 14 1 0 0",
/* colors */
"     s iconGray1     m white c #dededededede",
".	s none	m none	c none",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s bottomShadowColor m black c #636363636363",
"+    s iconGray3     m white c #adadadadadad",
"@	s iconColor2	m white	c white",
"#    s iconGray5     m black c #737373737373",
"$	s iconColor4	m white	c green",
"%    s iconGray6     m black c #636363636363",
"&    s iconGray8     m black c #212121212121",
"*    s iconGray7     m black c #424242424242",
"=	s iconColor1	m black	c black",
"-    s selectColor m white c #737373737373",
/* pixels */
"               .",
" XXXXoXXXXXXXXXO",
" Xooo+@@@@@@XXXO",
" X###$@oooo%XXXO",
"  ooo+&*o%**oooO",
" +###$+$@%#####O",
" +###+$+@%#####O",
" +###$+$@%#####O",
" %%%%+$X*&$#%%%O",
" X+++$+X*=-$*++O",
" X++++$X*=$-$*+O",
" X+##$+X*=#$+$*O",
" X+#X+$X*=--$+$O",
" X+#X$+$*=-$+$+$",
" X+#X+XX*=#XXXXO",
".OOOOOOO*=OOOOOO"};
