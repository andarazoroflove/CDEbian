/* XPM */
/* $XConsortium: Dtimage.s.pm /main/3 1995/07/18 16:41:05 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * arizona [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray4     m white c #949494949494",
"o	s iconColor1	m black	c black",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray5     m black c #737373737373",
"#    s iconGray6     m black c #636363636363",
"$    s iconGray3     m white c #adadadadadad",
/* pixels */
"   .............",
"   .XXXXXXXXXXXo",
"   .OOOOO+OOXOOo",
"   .OOO+X..XOO@o",
"   .O@@+X@.+@@@o",
"   .X@++XOO+#@@o",
"   .#@++@$++###o",
"   .##+++O++@##o",
"   .##++@.O++##o",
"   .+++++$@#+#@o",
"   .+++++++++##o",
"   .+++++++++++o",
"   .+++++++++++o",
"   .++++$+O.+++o",
"   .+++++$O@@++o",
"   .oooooooooooo"};
