/* XPM */
/* $XConsortium: DtBento.m.pm /main/3 1995/07/18 16:16:59 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtBento_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s iconGray5     m black c #737373737373",
"o    s iconGray3     m white c #adadadadadad",
"O    s iconGray4     m white c #949494949494",
"+	s iconColor2	m white	c white",
"@    s iconGray1     m white c #dededededede",
"#	s iconColor4	m white	c green",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"   .......................X     ",
"   .oooooooooooooOOOOOXXXXX     ",
"  .........................X    ",
"  .oooooooooooooooOOOOOXXXXX    ",
" O++++++++++++++++++++++++++X   ",
" O+OO@OO@@@@@@@@@@OOO@O@@#.@X   ",
" O+@@@@@@@@@@@@@@@@@@O@O@.#@X   ",
".O+OOO@O@@@@@@@@@@OOO@O@@#.@XO  ",
"+O+@@@@@@@@@@@@@@@@@@@@@@@.@XO  ",
"+O+@@@@@@@@@@@@@@@@@@@@@@@@@XO  ",
"+O+@@@@@@@@@@@@@@@@@@@@@.@.@Xo  ",
"+O+@@@@@@@@@@@@@@@@@@@@@@@@.Xo  ",
"+O+@@@@@@@@@@@@@@@@@@@@@.@.OXo  ",
"+O+.....@@OOOOO@OOOOO@.ooOOOXo  ",
"+@@@@@@X...@@@@@@@@@@@o.......  ",
"++@@..ooXoXXO@OOO@OOOo..oooOOX  ",
"+@@..oooXo..@@@@@@@@@o.oooooOX  ",
"++@@..ooXoo..@@@@@@@@o.ooooOOX  ",
"+@@..oooXXXOOOOOOOOOOO.oooooOX  ",
"++@@..oooooooooooooooooooooOOX  ",
"+@@..oooooooooooooooooooooooOX  ",
"++@@..oooooooooooooooooooooOOX  ",
"OOOOOOOOOOOOOOOOOOOOOOOOOOOOXX  "};
