/* XPM */
/* $XConsortium: Dtactn.m.pm /main/3 1995/07/18 16:26:36 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * action [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray6     m black c #636363636363",
"@	s iconColor2	m white	c white",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray8     m black c #212121212121",
"%    s iconGray5     m black c #737373737373",
"&	s iconColor5	m black	c blue",
"*	s iconColor3	m black	c red",
/* pixels */
"  .....................XXXo...  ",
" . O O O O O O O O O .++X@+X+O. ",
". O O O ooo o o O O .++X..@ O O#",
".O O O O O O O O O  $+$.@#%% O #",
". O O O O O O O O O$$$X..@@$O O#",
".O O O O O O O O O O$Oo...$$ O #",
". O O O O O O O O O O .XXo$ O O#",
".O O OoOoo O @.@@@@@&+X+$$ O O #",
". O O O O O @.oooooo&.+$O O O O#",
".O O O O O @.+oXoXo.&.o+ O O O #",
". O O O O @.X+$$$$$&&@&+O O O O#",
".O O O O @.X$O O@+&&+&+$+O O O #",
". O O O O.X$O Oo+&&+&+$++ O O  #",
".O O O #.#$O Oo+&&+++$$XX+ O .X.",
". O O $..$O O@+&+++$$ $+X....+X.",
".O O $@@$O O.*o+++$$ O $+XOOX$++",
". O O $$O O o+*o+$+ O O $$$$+ O#",
".O O O O O O+o+**+ O O O O O O #",
". O O O O O@+#O+oo. O O O O O O#",
".O O O O O..+##o..o. O O O O O #",
". O O O O .oX$%$+O.o@ O O O O O#",
".O O O O @oo+% O+$+o.@ O O O O #",
". O O O @.oX% O O @oX$O O O O O#",
".O O O X.oX% O O @oX$O O O O O #",
". O O @.X$% O O @.o$O O O O O O#",
".O O @.o$O O OX..O$O O O O O O #",
". O ..o$O O O@.X++O O O O O O O#",
".O@X.O$O O O +..@O O O O O O O #",
".@.XX+O O O O +...O O O O O O O#",
".$.@OO O O O O $$$ O O O O O O #",
" ##.@ O O O O O O O O O O O O # ",
"  #XX#########################  "};
