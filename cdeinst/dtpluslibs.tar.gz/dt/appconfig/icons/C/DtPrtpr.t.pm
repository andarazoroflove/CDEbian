/* XPM */
/* $XConsortium: DtPrtpr.t.pm /main/3 1995/07/18 16:25:05 drk $ */
static char * DtPrtpr_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 10 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray6     m black c #636363636363",
"o	s iconColor2	m white	c white",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s iconGray4     m white c #949494949494",
"@	s iconColor1	m black	c black",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray1     m white c #dededededede",
"%    s iconGray5     m black c #737373737373",
/* pixels */
"                ",
"                ",
"   ........X    ",
"   .oooooooX    ",
"  ..oooooooX..  ",
"..O+oooooooX@O# ",
".oO@@@@@@@@@@OO@",
".o$$$$$$$$$$$$$@",
".o$OOOOOOO$###$@",
".o$$$$$$$$$$##$@",
".o$$$$$$$$$$$$$@",
".o$+%%%%%%%%$$$@",
".+@o%%%%%%%%@@@@",
"  @@@@@@@@@@@@@ ",
"   #########.   ",
"                "};
