/* XPM */
/* $XConsortium: DtKeybd.pm /main/3 1995/07/18 16:21:22 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Keyboard [] = {
/* width height ncolors cpp [x_hot y_hot] */
"64 37 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray5     m black c #737373737373",
/* pixels */
"                                                                ",
"                                                                ",
"  ............................................................  ",
"  .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo  ",
"   .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"    .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"    .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"     .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"     .+++++++++++++++++++++++++++++++++++++++++++++++++++++++o  ",
"     .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX+o  ",
"     .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"      .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"      .@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@OO@@@@@@@@@@@@@@OOO+o  ",
"      .#OOO#OOO#OOO#OOO#OOO#OOO#OOOOOOO#XOO@OOO#OOO#OOO#XOOO+o  ",
"      .#O###O###O###O###O###O###O#######XOO@O###O###O###XOOO+o  ",
"      .#O###O###O###O###O###O###O#######XOO@O###O###O###XOOO+o  ",
"      .#################################XOO@############XOOO+o  ",
"      .##OOO#OOO#OOO#OOO#OOO#OOOO#OOOOO#XOO@OOO#OOO#OOO#XOOO+o  ",
"       .#O###O###O###O###O###O####O#####XOO@O###O###O###XOOO+o  ",
"       .#O###O###O###O###O###O####O#####XOO@O###O###O###XOOO+o  ",
"       .################################XOO@############XOOO+o  ",
"       .##OOO#OOO#OOO#OOO#OOO#OOOOOOOOO#XOO@OOO#OOO#####XOOO+o  ",
"       ..#O###O###O###O###O###O#########XOO@O###O#######XOOO+o  ",
"        .#O###O###O###O###O###O#########XOO@O###O#######XOOO+o  ",
"        .###############################XOO@############XOOO+o  ",
"        .OOOOOOOOOOOO#OOOOO#OOO#########XOO@OOO#########XOOO+o  ",
"        .#############O#####O###########XOO@O###########XOOO+o  ",
"        .#############O#####O###########XOO@O###########XOOO+o  ",
"         .##############################XOO@############XOOO+o  ",
"         .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXOO@XXXXXXXXXXXXXOOO+o  ",
"         .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"         .OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+o  ",
"         .+++++++++++++++++++++++++++++++++++++++++++++++++++o  ",
"         .+++++++++++++++++++++++++++++++++++++++++++++++++++o  ",
"         .oooooooooooooooooooooooooooooooooooooooooooooooooooo  ",
"                                                                ",
"                                                                "};
