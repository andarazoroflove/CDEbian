/* XPM */
/* $XConsortium: Fptrsh7.l.pm /main/3 1995/07/18 17:07:34 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Ftrash7 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X	s iconColor2	m white	c white",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray6     m black c #636363636363",
"+    s topShadowColor m white c #bdbdbdbdbdbd",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray7     m black c #424242424242",
"%    s iconGray5     m black c #737373737373",
"&    s iconGray3     m white c #adadadadadad",
"*    s iconGray4     m white c #949494949494",
"=	s iconColor1	m black	c black",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"              ......................            ",
"              .XXXXXoXoXoooooooooooO+           ",
"              .@@X@@@@@@@@@@@@@@@@@O+           ",
"              .@@X@@@@@@@@@@@@@@@@@O+           ",
"              .@@o@@@@@@@@@@@@@@@@@O+           ",
"              .#####################+           ",
"              .#$OOOO%&%&%&%&%&%OOO             ",
"              .&&$$$$$XX@X@X$$XX***..           ",
"              .&&@@@@@@XX@X$@@@@@@@@+           ",
"              .*&@******XX$O%******$+           ",
"              .*&@******$$O%*******$+           ",
"              .&&@*******OO%*******$+           ",
"              .*&@********%********$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****************$+           ",
"              .&&@*****************$+           ",
"              .*&@*****======******$+           ",
"              +=&@*****=oooooo%****$+           ",
"               +=@*****======%%****$+           ",
"                +===================+           ",
"                 +++++++     ++++++++           ",
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                                                "};
