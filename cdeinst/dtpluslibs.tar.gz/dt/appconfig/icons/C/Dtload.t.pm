/* XPM */
/* $XConsortium: Dtload.t.pm /main/3 1995/07/18 16:43:51 drk $ */
static char * Dtload_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".    s iconGray3     m white c #adadadadadad",
"X	s none	m none	c none",
"o    s iconGray8     m black c #212121212121",
"O	s iconColor7	m white	c cyan",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray1     m white c #dededededede",
/* pixels */
"                ",
" .X.X.X.X.X.X.Xo",
" X.X.X.X.X.X.X.o",
" .X.X.X.X.X.X.Xo",
" X.X.X.X.X.X.X.o",
" .X.X.X.XOO.X.Xo",
" X.X.X.X.++X.X.o",
" .X.X.X.OOO.X.Xo",
" @@@@@@@+@+@@@@o",
" .X.X.OOOOOOO.Xo",
" X.X.X+++++++X.o",
" OOOOOOOOOOOOOOo",
" +++++++++++++.o",
" OOOOOOOOOOOOOOo",
" ++++++++++++++o",
" ooooooooooooooo"};
