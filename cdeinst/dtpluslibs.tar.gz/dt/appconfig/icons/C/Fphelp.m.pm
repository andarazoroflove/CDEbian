/* XPM */
/* $XConsortium: Fphelp.m.pm /main/3 1995/07/18 16:57:52 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * help32 [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 15 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray3     m white c #adadadadadad",
"o    s iconGray7     m black c #424242424242",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray8     m black c #212121212121",
"#    s selectColor m white c #737373737373",
"$    s iconGray6     m black c #636363636363",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"&	s iconColor7	m white	c cyan",
"*	s iconColor3	m black	c red",
"=	s iconColor5	m black	c blue",
"-	s iconColor2	m white	c white",
";    s topShadowColor m white c #bdbdbdbdbdbd",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"                                ",
"       ......         .XXXXX    ",
"       .XXXo......    .XOO+@#   ",
"   ....@X+O$@OOOO$....@XOO$@##  ",
"   .%%X@&O+*@O+++$@=o$@XO+o@#   ",
"   .%X+@O+O$@O+++$@o+=@XO++@##  ",
"   .%O+@&O+*$-----@oo$@Xo++@#   ",
"   .%X+@O+O$-------=+=@XOO+@##  ",
"   .%X+@&O+*--ooo--oo$@Xo++@#   ",
"   .%O+@O+O$--o++--o+=@X+++@##  ",
"   .%X+@&O+*@oo+---oo$@X$++@#   ",
"   .%O+@O+O$@O+---@o+=@XO++@##  ",
"   .%O+@&O+*@O---o@oo$@X$++@#   ",
"   .%O+@O+O$@O--o$@=+=@X+++@##  ",
"   .%X+@&O+*@O+oo$@oo$@XOO+@#   ",
"   .%X+@O+O$@O--+$@=+=@XO++@##  ",
"   .%X+@&O+*@O--o$@oo$@XO++@#   ",
"   .%X+@O+O$@O$oo$@=+=@Xo++@##  ",
"   .%X+@&O+*@O+oo$@oo$@XO++@#   ",
"   .%X+@O+O$@O+++$@=+=@XO++@##  ",
"   .%X+@&O+*@O+++$@oo$@XO++@#   ",
"   .X@@@@@@@@@@@@@@@@@@X@@@@##  ",
"   .;;;;;;;;;;;;;;;;;;;;    #   ",
"                         #####  ",
"                          # #   ",
"                                ",
"                                "};
