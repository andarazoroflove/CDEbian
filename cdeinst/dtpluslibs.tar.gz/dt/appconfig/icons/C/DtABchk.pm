/* XPM */
/* $XConsortium: DtABchk.pm /main/3 1995/07/18 16:12:46 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * checkbox_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 5 1 0 0",
/* colors */
"     s iconGray4     m white c #949494949494",
".	s iconColor1	m black	c black",
"X    s iconGray6     m black c #636363636363",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O	s iconColor2	m white	c white",
/* pixels */
"                            ",
"     ..................     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXXo     ",
"     .XXXXXXXXXXXXXXXOo     ",
"     .XXXXXXXXXXXXXXOOo     ",
"     .XXOOXXXXXXXXOOOXo     ",
"     .XOOOOXXXXXXOOOXXo     ",
"     .OOOOOOXXXOOOOXXXo     ",
"     .XOOOOOOXOOOOXXXXo     ",
"     .XXOOOOOOOOOXXXXXo     ",
"     .XXXOOOOOOOXXXXXXo     ",
"     .XXXXOOOOOXXXXXXXo     ",
"     .XXXXXOOOXXXXXXXXo     ",
"     .ooooooooooooooooo     ",
"                            "};
