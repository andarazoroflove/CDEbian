/* XPM */
/* $XConsortium: DtABbil.t.pm /main/3 1995/07/18 16:11:23 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtABbip_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".    s iconGray6     m black c #636363636363",
"X	s none	m none	c none",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray7     m black c #424242424242",
"+	s iconColor4	m white	c green",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray4     m white c #949494949494",
"$	s iconColor1	m black	c black",
/* pixels */
"             .XX",
" oooooooooooo.XX",
" oooooooooooo.XX",
" o.o  OoOOooo.XX",
" . O  OO Oooo.XX",
" oO+OOO..Oooo.XX",
" o ++ +.ooooo.XX",
" o +@ #+.oooo.XX",
" o +$$$++.ooo.XX",
" o +$#$#++.oo.XX",
" o +$#$#o++.o.XX",
" o +$#$+++++..XX",
" oo#$#$#####o.XX",
" ...$#$.......XX",
"XXXX$#$XXXXXXXXX",
"XXXX$$$XXXXXXXXX"};
