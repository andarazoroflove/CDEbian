/* XPM */
/* $XConsortium: DtCMtdo.m.pm /main/3 1995/07/18 16:20:05 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMtdo_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 11 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".    s iconGray4     m white c #949494949494",
"X	s none	m none	c none",
"o    s iconGray2     m white c #bdbdbdbdbdbd",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray5     m black c #737373737373",
"@	s iconColor5	m black	c blue",
"#    s iconGray3     m white c #adadadadadad",
"$	s iconColor3	m black	c red",
"%    s iconGray1     m white c #dededededede",
"&	s iconColor6	m white	c yellow",
/* pixels */
"                           .XXXX",
" ooooooooooooooooooooooooooOXXXX",
" ooooooooooooooooooooooooooOXXXX",
" o++ @oooooooooooooooooooooOXXXX",
" o@@@o+++oo++o++++o++ooooooOXXXX",
" o @ ooooooooooooooooooooooOXXXX",
" ooooooooooooooooooooooooooOXXXX",
" ooooooooooooooooooo@#oooooOXXXX",
" ooooooooooooooooo@O##oooooOXXXX",
" o++ oooooooooooo@O##ooooooOXXXX",
" o+. o++@+oo++o@@O+#oooooooOXXXX",
" o   oo@@@oooo@@O##ooooooooOXXXX",
" ooooo@@@@@oo@@O##oooooooooOXXXX",
" ooooO@@@@@o@@O##ooooooo$ooOXXXX",
" oooooO@@@@@@O##ooooooo$$+oOXXXX",
" o   ooO@@@@@O#ooooooo#$+$OOXXXX",
" o o+o++O@@@O+#+++o++ %+$O#OXXXX",
" o ++ooooO@O##oooooo#%%oO##OXXXX",
" oooooooooO##oooooo &+oO##oOXXXX",
" oooooooooo#oooooo &.&O##ooOXXXX",
" oooooooooooooooo &.&O##oooOXXXX",
" o   ooooooooooo &.&O##ooooOXXXX",
" o o+o+++o++++o &.&O+#oooooOXXXX",
" o ++ooooooooo &.&O##ooooooOXXXX",
" oooooooooooo &.&O##oooooooOXXXX",
" ooooooooooo &.&O##ooooooooOXXXX",
" oooooooooo &.&O##oooooooooOXXXX",
" ooooooooo &.&O##ooooooooooOXXXX",
" oooooooo+o+&O##oooooooooooOXXXX",
" oooooooo++oO##ooooooooooooOXXXX",
" oooooooo++O##oooooooooooooOXXXX",
".OOOOOOOOOOOOOOOOOOOOOOOOOOOXXXX"};
