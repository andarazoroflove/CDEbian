/* XPM */
/* $XConsortium: DtABfsb2.pm /main/3 1995/07/18 16:13:18 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABfsb2_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 20 6 1 0 0",
/* colors */
"     s iconGray2     m white c #bdbdbdbdbdbd",
".    s iconGray6     m black c #636363636363",
"X    s iconGray7     m black c #424242424242",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray5     m black c #737373737373",
/* pixels */
"                            ",
" ..........................X",
" ..........................X",
" ooooooooooooooooooooooooooX",
" o........................oX",
" ooooooooooooooooooooooooooX",
" o........oo.o.........o.ooX",
" o........oo.o.........o.ooX",
" o........oo.o.........o.ooX",
" o........oo.o.........o.ooX",
" o........oo.o.........o.ooX",
" o........oo.o.........o.ooX",
" ooooooooooooooooooooooooooX",
" o........................oX",
" ooooooooooooooooooooooooooX",
" ooooooooooooooooooooooooooX",
" oOOO+ooooooOOO+ooooooOOO+oX",
" oO+++ooooooO+++ooooooO+++oX",
" ooooooooooooooooooooooooooX",
" XXXXXXXXXXXXXXXXXXXXXXXXXXX"};
