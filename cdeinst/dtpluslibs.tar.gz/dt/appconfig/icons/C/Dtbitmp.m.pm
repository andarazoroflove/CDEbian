/* XPM */
/* $XConsortium: Dtbitmp.m.pm /main/3 1995/07/18 16:31:35 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtbitmp_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 4 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
/* pixels */
"                         .......",
" XX    X    X    XooooXXo.......",
" XX    X    X    XooooXXo.......",
" XX    X    X    XooooXXo.......",
" XX    X    X    XooooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XX    X    X    X    XXo.......",
" XX    X    X    X    XXo.......",
" XX    X    X    X    XXo.......",
" XX    X    X    X    XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooooX    X    X    XXo.......",
" XXooooX    X    X    XXo.......",
" XXooooX    X    X    XXo.......",
" XXooooX    X    X    XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooooXooooX    X    XXo.......",
" XXooooXooooX    X    XXo.......",
" XXooooXooooX    X    XXo.......",
" XXooooXooooX    X    XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooooXooooXooooX    XXo.......",
" XXooooXooooXooooX    XXo.......",
" XXooooXooooXooooX    XXo.......",
" XXooooXooooXooooX    XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXooooXooooXooooXooooXXo.......",
" XXooooXooooXooooXooooXXo.......",
" XXooooXooooXooooXooooXXo.......",
" XXooooXooooXooooXooooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
