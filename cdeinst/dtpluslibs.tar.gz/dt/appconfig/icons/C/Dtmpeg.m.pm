/* XPM */
/* $XConsortium: Dtmpeg.m.pm /main/4 1995/07/31 11:17:48 lehors $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtmpeg_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
"     s iconGray3     m white c #adadadadadad",
".    s iconGray3     m white c #adadadadadad",
"X	s none	m none	c none",
"o    s iconGray8     m black c #212121212121",
"O	s iconColor1	m black	c black",
"+    s iconGray4     m white c #949494949494",
"@    s iconGray6     m black c #636363636363",
"#	s iconColor2 c m white c white",
"$    s iconGray5     m black c #737373737373",
"%    s iconGray2     m white c #bdbdbdbdbdbd",
"*    s iconGray2     m white c #bdbdbdbdbdbd",
"=	s iconColor5	m black	c blue",
"-    s iconGray7     m black c #424242424242",
/* pixels */
" ...................XXXXXXXXXXXX",
" ooooooooooooooooooOXXXXXXXXXXXX",
" ooooooo+++++ooooooOXXXXXXXXXXXX",
" ooooo+++     +ooooOXXXXXXXXXXXX",
" ooooo+        ooooOXXXXXXXXXXXX",
" ooooo+        ooooOXXXXXXXXXXXX",
" ooooo+ @@@@@  ooooOXXXXXXXXXXXX",
" ooooo+@@###@@ ooooOXXXXXXXXXXXX",
" ooooo+@#   #@ ooooOXXXXXXXXXXXX",
" ooooo+@# # #@ ooooOXXXXXXXXXXXX",
" $oooooooooooooooooOXXXXXXXXXXXX",
" ooooooo%%%%%%%ooooOXXXXXXXXXXXX",
" $oooo$o%@%%%%%ooooOXXXXXXXXXXXX",
" ooooo$o%@%@%%%ooooOXXXXXXXXXXXX",
" $oooooo%%%@%%%ooooOXXXXXXXXXXXX",
" ooooooo%@%+%%%ooooOXXXXXXXXXXXX",
" $oooooo%@%@%%%ooooOXXXXXXXXXXXX",
".ooooooo%%%%%%%ooooOXXXXXXXXXXXX",
".$oooooo%@%@%%%o%**********XXXXX",
".ooooo$o%@%+%%%o%=-=-=-=-=OXXXXX",
".$-ooooo%%%%%%%o%-#-=-=-#-OXXXXX",
".o-ooooooooooooo%=#=-=-=#=OXXXXX",
".$oooo@@# # #@@o%-##=-=##-OXXXXX",
".ooo-o@@#   #@@o%=#=#=#=#=OXXXXX",
".o-ooo@@@###@@@o%-#-#-#-#-OXXXXX",
".ooooo@@@@@@@@@o%=#=-#-=#=OXXXXX",
".ooooo@@@@@@@@@o%-#-=#=-#-OXXXXX",
".ooo-o@@@@@@@@@o%=-=-=-=-=OXXXXX",
".ooo-o@@@@@@@@@o%OOOOOOOOOOXXXXX",
" ooooooo@@@@@ooooooOXXXXXXXXXXXX",
" ooooooooooooooooooOXXXXXXXXXXXX",
" OOOOOOOOOOOOOOOOOOOXXXXXXXXXXXX"};
