/* XPM */
/* $XConsortium: Fpfphlp.l.pm /main/3 1995/07/18 16:56:58 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Ffphelp [] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 16 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor1	m black	c black",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray1     m white c #dededededede",
"#    s iconGray4     m white c #949494949494",
"$    s iconGray7     m black c #424242424242",
"%	s iconColor5	m black	c blue",
"&	s iconColor6	m white	c yellow",
"*    s background    m black c #949494949494",
"=	s iconColor3	m black	c red",
"-	s iconColor8	m black	c magenta",
";    s bottomShadowColor m black c #636363636363",
":    s selectColor m white c #737373737373",
/* pixels */
"                                                ",
"    ........................................    ",
"    .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo    ",
"    .O++++++++++++++++++++++++++++++++++++.o    ",
"    .O++++++++++++++++++++++++++++++++++++.o    ",
"    .O++++++++++++++++++++++++++++++++++++.o    ",
"    .O+++@@@+++@@@@+@@++++++++++++++++++++.o    ",
"    .O++++++++++++++++++++++++++++++++++++.o    ",
"    .O...................................#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$@$@@@$@$@$$@@$@@@$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$@$@@@$@@$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXX%+%X..+..+.XX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXX%%%X+...+..XX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXX&&&&&&&&&&&&&&&&&XXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",
"O+OOOOOO+OOOOOO+OOOOOO+OOOoooooooooooooooooooooo",
"**************************o*********************",
"**************************o*********************",
"$X#$**$&X#$**&XOO%**$X$#$*o****...........*$$$$$",
"&$##**X&$##**X=$XO**$#$##*o*%**...........*$$$$$",
"$-=***X$$=#**#$$&#**$$=$$*o*********************",
"=-%#**#=%%#**$$$$X**#&$%#*o****$$$$$$$$$$$*.....",
"#--***$###$**$$$$$**$#$#$*o*&**$$$$$$$$$$$*.....",
"**************************o*********************",
"**************************o*********************",
";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;",
"::::.#.OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO+. ::::",
"::::.#.OOOOO$O$$$$O$O$O$$$$$OOOOOOOOOOOOO+. ::::",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXX%%%%%%%%%%%XX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX#.o    ",
"    .O####################################.o    ",
"    .O####################################.o    ",
"    .......................................o    ",
"    .ooooooooooooooooooooooooooooooooooooooo    ",
"                                                "};
