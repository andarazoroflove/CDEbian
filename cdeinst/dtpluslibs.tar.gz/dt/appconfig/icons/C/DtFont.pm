/* XPM */
/* $XConsortium: DtFont.pm /main/3 1995/07/18 16:21:14 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Font [] = {
/* width height ncolors cpp [x_hot y_hot] */
"59 37 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray8     m black c #212121212121",
"o    s selectColor m white c #737373737373",
/* pixels */
"                                                           ",
"                                                           ",
"                                                           ",
"                                                           ",
"                                                           ",
"  ..........................                               ",
"  ...XXXXXXX......XXXXXXX...X                              ",
"  ..XXXXXXXXX....XXXXXXXXX..XX                             ",
"  .XXXoooooXX....XXXooooXXX.XXo                            ",
"  .XXoo     X....XXoo    XX.XXo                            ",
"  .Xoo       ....XXo      X.XXo                            ",
"  .Xo        ....XXo       XXXo                            ",
"    o        ....XXo        XXo                            ",
"             ....XXo    .................                  ",
"             ....XXo    ..XXXX.....XXXX..X                 ",
"             ....XXo    .XXXXXX...XXXXXX.XX                ",
"             ....XXo    .XXoooX...XXXooX.XXo               ",
"             ....XXo    .Xoo   ...XXoo  XXXo               ",
"             ....XXo      o    ...XXo    XXo               ",
"             ....XXo           ...XXo    ..............    ",
"             ....XXo           ...XXo    ..XXX....XXX..X   ",
"             ....XXo           ...XXo    .XXXXX..XXXXX.XX  ",
"             ....XXo           ...XXo    .Xoooo..XXooX.XXo ",
"             ....XXo           ...XXo      o   ..XXo  XXXo ",
"             ....XXo           ...XXo          ..XXo   XXo ",
"             ....XXo           ...XXo          ..XXo    oo ",
"             ....XXo           ...XXo          ..XXo       ",
"             ....XXo           ...XXo          ..XXo       ",
"             ....XXo           ...XXo          ..XXo       ",
"             ....XXo           ...XXo          ..XXo       ",
"            ......Xo           ...XXo          ..XXo       ",
"           ........o          .....Xo         ....Xo       ",
"         ............X      .........X      ........X      ",
"          XXXXXXXXXXXXX      XXXXXXXXXX      XXXXXXXXX     ",
"           XXXXXXXXXXXXX      XXXXXXXXXX      XXXXXXXXX    ",
"            ooooooooooooo      oooooooooo      ooooooooo   ",
"                                                           "};
