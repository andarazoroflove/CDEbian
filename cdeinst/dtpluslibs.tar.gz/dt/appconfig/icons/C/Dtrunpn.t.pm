/* XPM */
/* $XConsortium: Dtrunpn.t.pm /main/3 1995/07/18 17:11:35 drk $ */
static char * create_action_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray4     m white c #949494949494",
"o    s iconGray6     m black c #636363636363",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray7     m black c #424242424242",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray8     m black c #212121212121",
"%	s iconColor1	m black	c black",
"&	s iconColor5	m black	c blue",
"*	s iconColor6	m white	c yellow",
"=	s iconColor3	m black	c red",
/* pixels */
"  ........XoXo  ",
" . O O O OX+@#$ ",
". O O O O $++$O%",
".O O $+++& +$O %",
". O Oo+@X&+$O O%",
".O+O+%..O@oX O %",
". O@@%@**O@$++X+",
".O O O@@**O@$$$o",
". O Oo=@o**O@O %",
".O O $==@o**O@O%",
". O Oo$o+@o**O@%",
".O O+$ $$+@o**O%",
". O+$ O +$O@o*@@",
".O+$ O +$O O@o=@",
" +$ O +$O O O@@ ",
" $+%%%%+%%%%%%  "};
