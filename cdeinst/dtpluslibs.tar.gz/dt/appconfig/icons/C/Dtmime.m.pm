/* XPM */
/* $XConsortium: Dtmime.m.pm /main/3 1995/07/18 16:45:23 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtmime_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 14 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray5     m black c #737373737373",
"$    s iconGray6     m black c #636363636363",
"%	s iconColor8	m black	c magenta",
"&	s iconColor7	m white	c cyan",
"*	s iconColor3	m black	c red",
"=	s iconColor6	m white	c yellow",
"-	s iconColor5	m black	c blue",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXoXoOXoOooXO+XOXooXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOoXOoOXOOOXoOOoXOooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoXooXoXooooXoXooXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOoX@oOXXX@##@@@$##oXXo.......",
" XXXXXXXXXXX$$$#XX@#@oXXo.......",
" XXoooOOooXX$OO$$%@@#oXXo.......",
" XXXXXXXXXXX@&OOO$$$$oXXo.......",
" XXooXooXoXX*@OO$$#$$oXXo.......",
" XXXXXXXXXXX@&OOO$=&=oXXo.......",
" XXoOXOoXoXX*-OOO$&=&oXXo.......",
" XXXXXXXXXXX@O-OO$$@@oXXo.......",
" XXoOooOXoXX$-%O$O@@@oXXo.......",
" XXXXXXXXXXX$$$$$%@$$oXXo.......",
" XXoooOXOoXXooooooooooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOXXXXXXXXXXXX=OXXOXXXo.......",
" XXXXXXXXXXX-OXX=OXXXXXXo.......",
" XXOX*OXXXXX-OXX=OXXOXXXo.......",
" XXXX*OX OXX-OXX=OXXXXXXo.......",
" XXOX*OX OXX-OXX=OXXOXXXo.......",
" XXXX*OX OXX-OXX=OXXXXXXo.......",
" XXOOOOOOOOOOOOOOOOOOXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
