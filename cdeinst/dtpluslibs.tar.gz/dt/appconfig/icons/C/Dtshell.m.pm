/* XPM */
/* $XConsortium: Dtshell.m.pm /main/3 1995/07/18 17:12:00 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtshell_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 5 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray4     m white c #949494949494",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXOOOXOOOXXXXXXXXo.......",
" XXXXXXOOOOOXOOOOOXXXXXXo.......",
" XXXXXOOXOOOXOOOXOOXXXXXo.......",
" XXXXOOOXOOOXOOOXOOOXXXXo.......",
" XXXOXOOXOOOXOOOXOOXOXXXo.......",
" XXOOXOOOXOOXOOXOOOXOOXXo.......",
" XXOOOXOOXOOXOOXOOXOOOXXo.......",
" XOOOOXOOXOOXOOXOOXOOOOXo.......",
" XOOOOOXOOXOXOXOOXOOOOOXo.......",
" XOXOOOXOOXOXOXOOXOOOXOXo.......",
" XOOXOOOXOXOXOXOXOOOXOOXo.......",
" XXOOXOOXOOOXOOOXOOXOOXXo.......",
" XXXOOXOOXOOXOOXOOXOOXXXo.......",
" XXXXOOXOXOXXXOXOXOOXXXXo.......",
" XXXXXXOXOOOXOOOXOXXXXXXo.......",
" XXXXXXXOOOOOOOOOXXXXXXXo.......",
" XXXXXXOOOOOOOOOOOXXXXXXo.......",
" XXXXXOOOOOOOOOOOOOXXXXXo.......",
" XXXXXXXXXXOOOXXXXXXXXXXo.......",
" XXXXXXXXXXXOXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
