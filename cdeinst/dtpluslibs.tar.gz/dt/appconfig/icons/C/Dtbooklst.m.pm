/* XPM */
/* $XConsortium: Dtbooklst.m.pm /main/3 1996/07/23 12:06:23 drk $ */
/* $XConsortium: Dtbooklst.m.pm /main/3 1996/07/23 12:06:23 drk $ */
/*
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
static char * Dtbooklst3_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 14 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s iconGray5	m black	c #737373737373",
"X	s iconGray6	m black	c #636363636363",
"o	s iconColor1	m black	c black",
"O	s iconGray2	m white	c #bdbdbdbdbdbd",
"+	s iconGray7	m black	c #424242424242",
"@	s iconGray4	m white	c #949494949494",
"#	s iconColor5	m black	c blue",
"$	s iconColor7	m white	c cyan",
"%	s iconColor8	m black	c magenta",
"&	s iconColor3	m black	c red",
"*	s iconColor4	m white	c green",
"=	s iconColor6	m white	c yellow",
"-	s iconGray8	m black	c #212121212121",
/* pixels */
"                                ",
" .XXXXXXXXXXXXXXXXXXXXXXXXXXXXXo",
" .OOOOOOOXOOOOOOOOOOOOOXOOOOOOOo",
" .OOOOOOOXOOOOOOOOOOOOOXOO   +Oo",
" .O    XOXOOOOOOOOOOOOOXOO @@+Oo",
" .O+++++OXOOOOOOOOOOOOOXOO @@+Oo",
" .OOOOOOOXOOOOOOOOOOOOOXOOX+++Oo",
" .OOOOOOOXOOOOOOOOOOOOOXOOOOOOOo",
" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXo",
" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOo",
" OO#$OO%&OO.&OO*=OO*#OO&=OO.#OOo",
" OOX#OO&%OO&.OO=*OO#.OO=&OO#.OOo",
" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOo",
" O+++++++++++++++++++++++++++ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@-@---@------------@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@-@---@------------@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@@@@-@---@------------@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@@@@-@---@------------@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@-@---@------------@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@-@---@------------@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O+@@@@@@@@@@@@@@@@@@@@@@@@@@ Oo",
" O                            Oo",
" OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOo",
" ooooooooooooooooooooooooooooooo"};
