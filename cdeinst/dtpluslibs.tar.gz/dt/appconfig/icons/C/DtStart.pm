/* XPM */
/* $XConsortium: DtStart.pm /main/3 1995/07/18 16:26:10 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Startup [] = {
/* width height ncolors cpp [x_hot y_hot] */
"54 37 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray1     m white c #dededededede",
"o	s iconColor5	m black	c blue",
"O    s iconGray5     m black c #737373737373",
"+    s iconGray7     m black c #424242424242",
"@	s iconColor2	m white	c white",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray6     m black c #636363636363",
"%    s selectColor m white c #737373737373",
"&	s iconColor1	m black	c black",
"*    s topShadowColor m white c #bdbdbdbdbdbd",
/* pixels */
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"     ...............                                  ",
"    .XXXXXXXXXXXXXXX.                                 ",
"   .XXoXoXoXoXoXoXoXO.                                ",
"  .XOXOXOXOXOXOXOXOXO+............................    ",
"  .XoXoXoXoXoXoXoXoXO+@@@@@@@@@@@@@@@@@@@@@@@@@@@@.   ",
"  .XOXOXOXOXOXOXOXOXO+########################+####.  ",
"  .Xo$###XoXoXoXoXoXO+XXXX@@XXXXXXX@@XXXXXXXX@@@XXX.  ",
"  .XO#%%%XOXOXOXOXOXO+&&&&&&&&&&&&&&&&&&&&&&&######.  ",
"  .Xo#%% XoXoXoXoXoXO+XXXXXXXXXXXXXXXXXXXXXXXXXXXO*   ",
"  .XO#%  XOXOXOXOXOXO+XX@@@X@@@@@XX@O##XX@##@X##O*    ",
"  .Xo#%% XoXoXoXoXoXO+XX@##@@@###@@O#*#@@##*#@#**     ",
"  .XO#%  XOXOXOXOXOXO+X@####@##**###* *##** ****      ",
"  .XoXXXXXoXoXoXoXoXO+@##**###* ****   **             ",
"  .XOXOXOXOXOXOXOXOXO###*  ***                        ",
"  .XoXoXoXoXoXoXoXoXO#**                              ",
"  .XOXOXOXOXOXOXOXOXO#*                               ",
"   .oXoXoXoXoXoXoXoXO#*                               ",
"    *################*                                ",
"     ****************                                 ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      ",
"                                                      "};
