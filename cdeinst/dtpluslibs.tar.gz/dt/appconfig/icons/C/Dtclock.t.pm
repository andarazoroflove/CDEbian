/* XPM */
/* $XConsortium: Dtclock.t.pm /main/3 1995/07/18 17:09:53 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * clock [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s bottomShadowColor m black c #636363636363",
"o    s iconGray8     m black c #212121212121",
"O    s selectColor m white c #737373737373",
"+	s iconColor2	m white	c white",
"@    s topShadowColor m white c #bdbdbdbdbdbd",
"#    s iconGray3     m white c #adadadadadad",
/* pixels */
" .............. ",
". XXXXXXXXXXXX o",
".XXOOOO++OOOOXXo",
".XOOOOOOOOOOOO@o",
".XOO+OOOOOOOOO@o",
".XOOO+OOOO+OOO@o",
".XOOOO+OO+o#OO@o",
".X+OOOO++o#OO+@o",
".X+OOOO+oOOOO+@o",
".XOOOOOOOOOOOO@o",
".XOOOOOOOOOOOO@o",
".XOOOOOOOOOOOO@o",
".XOOOOOOOOOOOO@o",
".XXOOOO++OOOO@@o",
". X@@@@@@@@@@@ o",
" oooooooooooooo "};
