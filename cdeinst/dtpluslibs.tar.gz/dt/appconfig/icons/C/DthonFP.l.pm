/* XPM */
/* $XConsortium: DthonFP.l.pm /main/3 1995/07/18 16:40:10 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard. */
static char *helponFP48[]={
/* width height ncolors cpp [x_hot y_hot] */
"48 48 21 1 0 0",
/* colors */
"  c none m none s none",
"/    s topShadowColor m white c #bdbdbdbdbdbd",
"=    s background    m black c #949494949494",
";    s selectColor m white c #737373737373",
"\    s bottomShadowColor m black c #636363636363",
"x s iconColor1 c black     m black",
". s iconColor2 c white     m white",
"r s iconColor3 c red       m black",
"g s iconColor4 c green     m white",
"b s iconColor5 c blue      m black",
"y s iconColor6 c yellow    m black",
"c s iconColor7 c cyan      m white",
"m s iconColor8 c magenta   m white",
"1    s iconGray1     m white c #dededededede",
"2    s iconGray2     m white c #bdbdbdbdbdbd",
"3    s iconGray3     m white c #adadadadadad",
"4    s iconGray4     m white c #949494949494",
"5    s iconGray5     m black c #737373737373",
"6    s iconGray6     m black c #636363636363",
"7    s iconGray7     m black c #424242424242",
"8    s iconGray8     m black c #212121212121",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"                         \\\\\\\                ",
"                       \\1111111\\              ",
"                     \\11444444411\\            ",
"                    \114444444444411\\          ",
"                   \14444444444444441//         ",
"                  \1444644444644444647/         ",
"                 \1444444.......4444447/        ",
"                 \164644.........644467/        ",
"                \144444....444....444447/       ",
"                \146464...46464...464647/       ",
"               \1444644...64444...4464447/      ",
"               \1646464...46464...4646467/      ",
"               \14644464646444....6444647/      ",
"              x\1646464646464....64646467/      ",
"              x\146464646464....646464647/      ",
"              x\16464666464....6466646467/      ",
"              x\14646464646...64646464647/      ",
"             xxx\1666646664...4666466647/       ",
"             xxx\16464646464646464646467/       ",
"             xxx\1666666666...666666667/        ",
"             xxxx\146464646...646464647/        ",
"             xxxxx\66666666...66666667/         ",
"            xxxxxx\174666466646664667/          ",
"            xxxxxxx\/776666666666677/           ",
"            xxxxxxxxx//77666666477//            ",
"            xxxxxxxxxxx//7777777//              ",
"            xxxxxxxxxxxxx///////                ",
"       x   xxxxxxxxxxxxxxxxxxxx                 ",
"       x   xxxxxxxxxxxxxxxxxx                   ",
"       xx  xxxxxxxxxxxxxxx     222222           ",
"       xxx xxxxxxxxxx          /====;           ",
"       xxxxxxxxx               /y=44;           ",
"       xxxxx                   /====;           ",
"       xxxxxx                  /;=44;           ",
"       xxxxxxx                 /====;           ",
"       xxxxxxxxx               /4=44;           ",
"                               /====;           ",
"2222222222222222=;;;;;;=;;;;;;=22222222222222222",
"/=;=;3=;4=;;=;;=;;b;b;b=;;;;;;;=;4=;;=;4=;r=3;=\",
"/;;=3;=y;=rb=;3=================b;=y;=b;=43=3;=\",
"/;;=;;=;4====;;=;;;;;;;=;;;;;;;=34=;;=;;=;;=3;=\",
"/================;r;r;r=;;;;;;=================\",
"\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\",
"                                                "
};
