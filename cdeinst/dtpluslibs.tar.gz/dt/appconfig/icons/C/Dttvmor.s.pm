/* XPM */
/* $XConsortium: Dttvmor.s.pm /main/3 1995/07/18 16:52:15 drk $ */
/*************************************************************************/
/**  (c) Copyright 1993, 1994 Hewlett-Packard Company			**/
/**  (c) Copyright 1993, 1994 International Business Machines Corp.	**/
/**  (c) Copyright 1993, 1994 Sun Microsystems, Inc.			**/
/**  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary	**/
/**      of Novell, Inc.						**/
/*************************************************************************/

static char * tree_more_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"14 14 4 1 0 0",
/* colors */
"     s topShadowColor m white c #bdbdbdbdbdbd",
".    s background    m black c #949494949494",
"X    s bottomShadowColor m black c #636363636363",
"o	s foreground	m white	c white",
/* pixels */
"              ",
" ............X",
" ............X",
" .....oo.....X",
" .....oo.....X",
" .....oo.....X",
" ..oooooooo..X",
" ..oooooooo..X",
" .....oo.....X",
" .....oo.....X",
" .....oo.....X",
" ............X",
" ............X",
" XXXXXXXXXXXXX"};
