/* XPM */
/* $XConsortium: Dtmagtp.m.pm /main/3 1995/07/18 16:44:08 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtmagtp_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray6     m black c #636363636363",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray8     m black c #212121212121",
"#    s iconGray5     m black c #737373737373",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXOOOOOOOOOOOOOOOOOXXXo.......",
" XXXO+++++++++++++++O@XXo.......",
" XXXO+++++++++++++++O@XXo.......",
" XXX#################@XXo.......",
" XXX###OOOOOOOOOOO###@XXo.......",
" XXX##OOXXOOOOOXXOO##@XXo.......",
" XXX##OX@@XOOOX@@XO##@XXo.......",
" XXX##OX@@XOOOX@@XO##@XXo.......",
" XXX##OOXXOOOOOXXOO##@XXo.......",
" XXX###OOOOOOOOOOO###@XXo.......",
" XXX#################@XXo.......",
" XXX#################@XXo.......",
" XXXX@@@@@@@@@@@@@@@@@XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
