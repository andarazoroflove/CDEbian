/* XPM */
/* $XConsortium: DtABlst.pm /main/3 1995/07/18 16:14:00 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABlst_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 16 5 1 0 0",
/* colors */
"     s iconGray3     m white c #adadadadadad",
".    s iconGray7     m black c #424242424242",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                        ",
" ..................  X  ",
" .ooooooooooooooooX  .  ",
" .oOoooOOoooooooooX  X  ",
" .oOoOoOooooooooooX  X  ",
" .ooooooooooooooooX  X  ",
" .ooooooooooooooooX  X  ",
" .oOoOOooOooooooooX  X  ",
" .oOooooOoOoooooooX  X  ",
" .ooooooooooooooooX  .  ",
" .ooooooooooooooooX  .  ",
" .oOoOooOoooooooooX  .  ",
" .oOooOoooooooooooX  .  ",
" .ooooooooooooooooX  .  ",
" .XXXXXXXXXXXXXXXXX  X  ",
"                        "};
