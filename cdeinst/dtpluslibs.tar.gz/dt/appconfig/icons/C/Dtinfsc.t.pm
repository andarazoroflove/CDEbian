/* XPM */
/* $XConsortium: Dtinfsc.t.pm /main/3 1996/06/17 13:54:05 rcs $
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
static char * Dtinfosect_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X	s iconGray2	m white	c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O	s iconGray7	m black	c #424242424242",
"+	s iconGray6	m black	c #636363636363",
"@	s iconColor6	m white	c yellow",
"#	s iconGray5	m black	c #737373737373",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" XXoOXOOXO+Xo...",
" XXXXX@ XXXXo...",
" XXo#X @XX+Xo...",
" XXXXXXXXXXXo...",
" XXoX@ @X#+Xo...",
" XXXXX@ XXXXo...",
" XXoX# @##XXo...",
" XXXXX@ XXXXo...",
" XXoXO @XOXXo...",
" XXXXX@@@XXXo...",
" XXo+Xo+o+XXo...",
" XXXXXXXXXXXo...",
" oooooooooooo..."};
 *
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */
/* XPM */
static char * Dtinfosect_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X	s iconGray2	m white	c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O	s iconGray7	m black	c #424242424242",
"+	s iconGray6	m black	c #636363636363",
"@	s iconColor6	m white	c yellow",
"#	s iconGray5	m black	c #737373737373",
/* pixels */
"             ...",
" XXXXXXXXXXXo...",
" XXXXXXXXXXXo...",
" XXoOXOOXO+Xo...",
" XXXXX@ XXXXo...",
" XXo#X @XX+Xo...",
" XXXXXXXXXXXo...",
" XXoX@ @X#+Xo...",
" XXXXX@ XXXXo...",
" XXoX# @##XXo...",
" XXXXX@ XXXXo...",
" XXoXO @XOXXo...",
" XXXXX@@@XXXo...",
" XXo+Xo+o+XXo...",
" XXXXXXXXXXXo...",
" oooooooooooo..."};
