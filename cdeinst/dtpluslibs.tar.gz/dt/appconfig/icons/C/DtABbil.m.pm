/* XPM */
/* $XConsortium: DtABbil.m.pm /main/3 1995/07/18 16:11:14 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtABil_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O	s iconColor4	m white	c green",
"+    s iconGray1     m white c #dededededede",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray3     m white c #adadadadadad",
"$    s iconGray6     m black c #636363636363",
"%    s iconGray7     m black c #424242424242",
"&    s iconGray5     m black c #737373737373",
"*    s selectColor m white c #737373737373",
"=    s iconGray8     m black c #212121212121",
/* pixels */
"                                ",
"                                ",
"                                ",
".....................           ",
".XXXXXXXXXXXXXXXXXXXo           ",
".XXOXXXXXXXXXXXXXXXXo           ",
".XXOO.+X....@X...XXXo           ",
".XXO..@#....$$.#$@XXo           ",
".XXO+.@%XXXX$$+#$@XXo           ",
".XXOO&&O%$$$$@$$$@XXo           ",
".XXO.O#O#.+$@@@@@@XXo           ",
".XXOO.O.O.+$@XXXXXXXo           ",
".XXO.O.O..+$@XXXXXXXo           ",
".XXOO.O@O.+$OXXXXXXXo           ",
".XXO.OO@@.+$#OXXXXXXo           ",
".XXOO.O@X.+$O.OXXXXXo           ",
".XXO.OO@&@&ooO.OXXXXo           ",
".XXOO.O@&@&oo.O.OXXXo           ",
".XXO.OO@&@&ooO.O.OXXo           ",
".XXOO.O@&@&oo@O.O.OXo           ",
".XXO.OO@&@&oo@XO.O.Oo           ",
".XXOO.O@&@&oo@XXO.O.O           ",
".XXO.O.O&@&ooOOOOO.O.O          ",
".XXOO.O.&@&oo#O.O.O.O.O         ",
".XXO.O.O&@&ooO.O.O.O.O.O        ",
".XXOOOOO&@&ooOOOOOOOOOOOO       ",
".XXX@@@@&@&oo@@@@@@@o***        ",
".XXXXXXX&@&oo@XXXXXXo           ",
".XXXXXXX&@&oo@XXXXXXo           ",
".XXXXXXX&@&oo@XXXXXXo           ",
".=======&@&oo=======o           ",
"        ooooo                   "};
