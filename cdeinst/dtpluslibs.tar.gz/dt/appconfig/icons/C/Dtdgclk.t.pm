/* XPM */
/* $XConsortium: Dtdgclk.t.pm /main/3 1995/07/18 16:34:16 drk $ */
static char * Dtdgclk_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
"     s iconGray1     m white c #dededededede",
".    s iconGray3     m white c #adadadadadad",
"X	s iconColor1	m black	c black",
"o    s iconGray8     m black c #212121212121",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor6	m white	c yellow",
/* pixels */
"                ",
" ..............X",
" ..............X",
" ..............X",
" ..............X",
" ..oooooooooo..X",
" .oOOOOOOOOOO .X",
" .oO+O+O+O+OO .X",
" .oO++O+O+O+O .X",
" .oOOOOOOOOOO .X",
" ..          ..X",
" ..............X",
" ..............X",
" ..............X",
" ..............X",
" XXXXXXXXXXXXXXX"};
