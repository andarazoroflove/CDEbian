/* XPM */
/* $XConsortium: Dthover.l.pm /main/3 1995/07/18 17:10:35 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

/* Designed by the User Interaction Design Group, Hewlett-Packard. */
static char *helpoverview48[]={
/* width height ncolors cpp [x_hot y_hot] */
"48 48 21 1 0 0",
/* colors */
"  c none m none s none",
"/    s topShadowColor m white c #bdbdbdbdbdbd",
"=    s background    m black c #949494949494",
";    s selectColor m white c #737373737373",
"\    s bottomShadowColor m black c #636363636363",
"x s iconColor1 c black     m black",
". s iconColor2 c white     m white",
"r s iconColor3 c red       m black",
"g s iconColor4 c green     m white",
"b s iconColor5 c blue      m black",
"y s iconColor6 c yellow    m black",
"c s iconColor7 c cyan      m white",
"m s iconColor8 c magenta   m white",
"1    s iconGray1     m white c #dededededede",
"2    s iconGray2     m white c #bdbdbdbdbdbd",
"3    s iconGray3     m white c #adadadadadad",
"4    s iconGray4     m white c #949494949494",
"5    s iconGray5     m black c #737373737373",
"6    s iconGray6     m black c #636363636363",
"7    s iconGray7     m black c #424242424242",
"8    s iconGray8     m black c #212121212121",
/* pixels */
"                                                ",
"    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx    ",
"    x22222222222222222222222222222222222222/    ",
"    x3555555555555555555555555555555555555x/    ",
"    x3555555555555555555555555555555555555x/    ",
"    x3555555555555555555555555555555555555x/    ",
"    x3555111555111151155555555555555555555x/    ",
"    x3555555555555555555555555555555555555x/    ",
"    x3xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx5x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x77171117171771171117777777777777774x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x77777171117117777777777777777777774x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x77777777777777777777777777777777774x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x222222222222222222222b5b2xx5xx5x224x/    ",
"    x3x222222222222222222222bbb25xxx5xx224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x2222yyyyyyyyyyyyyyyyy22222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22227x2xx5xx22222222222222222222224x/    ",
"    x3x22225x2x5x5522222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x2222x2x2xx2222222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3xrrr2x5x2722572x52x72x272x2522222224x/    ",
"    x3xrrr272x25x2x225xx2xx52xx5x522222224x/    ",
"    x3xrrr22222222222222222222222222222224x/    ",
"    x3x22222727772727277727277277722222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222727777272727772772722222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222727777272727777722222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x222222222222222222222bbbbbbbbbbb224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3x22222222222222222222222222222222224x/    ",
"    x3444444444444444444444444444444444444x/    ",
"    x3444444444444444444444444444444444444x/    ",
"    xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx/    ",
"    x///////////////////////////////////////    ",
"                                                "
};
