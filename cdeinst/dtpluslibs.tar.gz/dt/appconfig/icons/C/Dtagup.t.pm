/* XPM */
/* $XConsortium: Dtagup.t.pm /main/3 1995/07/18 16:27:46 drk $ */
static char * Dtagup [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor1	m black	c black",
"o	s iconColor5	m black	c blue",
"O    s iconGray5     m black c #737373737373",
"+    s iconGray8     m black c #212121212121",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray4     m white c #949494949494",
"$    s iconGray6     m black c #636363636363",
/* pixels */
" ..........X    ",
" .oooooooooX    ",
"....ooooo...X   ",
".OO.......OOX   ",
".OOOOOOOOOOO+   ",
".OOO..........X ",
".OOO.oooooooooX ",
".OO....ooooo...X",
".OO.@@.......##X",
".OO.XXXXX######X",
"XXX.XXXX#######X",
"   .XXX$#######X",
"   .XX$X$######X",
"   .X##$X$#####X",
"   .####$X$####X",
"   XXXXXXXXXXXXX"};
