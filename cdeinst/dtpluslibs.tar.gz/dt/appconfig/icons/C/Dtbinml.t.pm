/* XPM */
/* $XConsortium: Dtbinml.t.pm /main/3 1995/07/18 16:31:26 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtbinml_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray4     m white c #949494949494",
"o	s iconColor1	m black	c black",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"     ...........",
" XXXo...........",
" X       .......",
" X OOOOOo.......",
" X OOOOOo.......",
" o O         ...",
".. O ++o++o+o...",
".. O +o+o+o+o...",
".. O +o+o+o+o...",
".. O ++o++o+o...",
".. o +++++++o...",
".... +o++o++o...",
".... +o+o+o+o...",
".... +o+o+o+o...",
".... +o++o++o...",
".... oooooooo..."};
