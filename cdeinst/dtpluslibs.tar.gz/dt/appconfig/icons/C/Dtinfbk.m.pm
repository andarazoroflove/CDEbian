/* XPM */
/* $XConsortium: Dtinfbk.m.pm /main/3 1995/07/18 16:41:59 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtinfbk_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o    s iconGray5     m black c #737373737373",
"O	s iconColor1	m black	c black",
"+    s iconGray6     m black c #636363636363",
/* pixels */
"                       .........",
" XoXXXXXXXXXXXXXXXXXXXO.........",
" XoXXXXXXXXXXXXXXXXXXXO+........",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXOOOXOXOOXOOXOXXXO+O.......",
" XoXXOOXOXXOXOXOXOOOXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXXOOXO  OXOOXOXXXO+O.......",
" XoXOOOXOO    XOXXOXXXO+O.......",
" XoXXXXXXX    oXXXXXXXO+O.......",
" XoXXXXXXXX  ooXXXXXXXO+O.......",
" XoXXOOXOXXXooXOXOOXXXO+O.......",
" XoXXXXXXX   XXXXXXXXXO+O.......",
" XoXXXXXX     XXXXXXXXO+O.......",
" XoXXXXX      oXXXXXXXO+O.......",
" XoXXXXXXo    oXXXXXXXO+O.......",
" XoXXXXXXX    oXXXXXXXO+O.......",
" XoXXXXXXX    oXXXXXXXO+O.......",
" XoXXXXXXX    oXXXXXXXO+O.......",
" XoXXXXXXX      XXXXXXO+O.......",
" XoXXXXXXX     oXXXXXXO+O.......",
" XoXXXXXXXX   oXXXXXXXO+O.......",
" XoXXXXXXXOOOOXXXXXXXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXXOOOOOXOOOOOXXXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" XoXXXXXXXXXXXXXXXXXXXO+O.......",
" OOOOOOOOOOOOOOOOOOOOOO+O.......",
" OO+++++++++++++++++++++O.......",
". OOOOOOOOOOOOOOOOOOOOOOO......."};
