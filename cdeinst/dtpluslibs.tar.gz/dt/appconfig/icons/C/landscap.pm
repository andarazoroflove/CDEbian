/* XPM */
/* $XConsortium: landscap.pm /main/3 1996/08/12 18:43:47 cde-hp $ */
/*
 * (c) Copyright 1996 Digital Equipment Corporation.
 * (c) Copyright 1996 Hewlett-Packard Company.
 * (c) Copyright 1996 International Business Machines Corp.
 * (c) Copyright 1996 Sun Microsystems, Inc.
 * (c) Copyright 1996 Novell, Inc. 
 * (c) Copyright 1996 FUJITSU LIMITED.
 * (c) Copyright 1996 Hitachi.
 */

static char * landscap [] = {
/* width height ncolors cpp [x_hot y_hot] */
"28 22 3 1 0 0",
/* colors */
" 	s iconColor1	m black	c black",
".	s background	m black	c #969696969696",
"X	s iconColor2	m white	c white",
/* pixels */
"                        ....",
" XXXXXXXXXXXXXXXXXXXXXX  ...",
" XXXXXXXXXXXXXXXXXXXXXX X ..",
" XXXXXXXXXXXXXXXXXXXXXX X ..",
" XXXXXXXXXXXXXXXXXXXXXX XX .",
" XXXXXXXXXXX  XXXXXXXXX     ",
" XXXXXXXXXXX  XXXXXXXXXXXXX ",
" XXXXXXXXXXX  XXXXXXXXXXXXX ",
" XXXXXXXXXX  X XXXXXXXXXXXX ",
" XXXXXXXXXX  X XXXXXXXXXXXX ",
" XXXXXXXXX  XXX XXXXXXXXXXX ",
" XXXXXXXXX  XXX XXXXXXXXXXX ",
" XXXXXXXX        XXXXXXXXXX ",
" XXXXXXXX  XXXXX XXXXXXXXXX ",
" XXXXXXXX  XXXXX XXXXXXXXXX ",
" XXXXXXX  XXXXXX  XXXXXXXXX ",
" XXXXXX     XXX    XXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
" XXXXXXXXXXXXXXXXXXXXXXXXXX ",
"                            "};
