/* XPM */
/* $XConsortium: DtCMapt.s.pm /main/3 1995/07/18 16:18:59 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMapt_s_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"24 24 10 1 0 0",
/* colors */
"     s background    m black c #949494949494",
".	s iconColor1	m black	c black",
"X	s iconColor2	m white	c white",
"o    s selectColor m white c #737373737373",
"O    s iconGray1     m white c #dededededede",
"+    s iconGray3     m white c #adadadadadad",
"@	s iconColor5	m black	c blue",
"#    s iconGray4     m white c #949494949494",
"$    s iconGray2     m white c #bdbdbdbdbdbd",
"%    s iconGray5     m black c #737373737373",
/* pixels */
"                        ",
" .....................  ",
" .XXXXXXXXXXXXXXXXXXX.o ",
" .XOOOOOOOOOOOOOOOOO+.o ",
" .XOOOOOOOOOOOOOOOOO+.o ",
" .XOOOOOOOOO@@@@@OOO+.o ",
" .XO##O###@@$O%O$@@O+.o ",
" .XOOOOOO@$XXXXXXX$@+.o ",
" .XOOOOO@$%XXXXXXX%$@.o ",
" .XOOOO@$XXXXXXXXXXX$@o ",
" .XO###@OXXXXXXXXX$XO@o ",
" .XOOO@$XXX$XXXXX$@XX$@ ",
" .XOOO@OXXX@$XXX$@XXXO@ ",
" .XO##@%XXXX@$X$@XXXX%@ ",
" .XOOO@OXXXXX@$@XXXXXO@ ",
" .XOOO@$XXXXXX@XXXXXX$@ ",
" .XOOOO@OXXXXXXXXXXXX@o ",
" .XO##O@$XXXXXXXXXX%$@o ",
" .XOOOOO@$%XXXXXXXX$@.o ",
" .XOOOOOO@$XXXXXXO$@+.o ",
" .XOOOOOOO@@$O%O$@@O+.o ",
" .X+++++++++@@@@@++++.o ",
" .....................  ",
"                        "};
