/* XPM */
/* $XConsortium: DtABfsb.pm /main/3 1995/07/18 16:13:11 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtABfsb_x_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 32 8 1 0 0",
/* colors */
"     s iconGray2     m white c #bdbdbdbdbdbd",
".	s iconColor1	m black	c black",
"X    s iconGray5     m black c #737373737373",
"o    s iconGray6     m black c #636363636363",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray3     m white c #adadadadadad",
"@    s iconGray4     m white c #949494949494",
"#    s iconGray2     m white c #bdbdbdbdbdbd",
/* pixels */
"                                               .",
" XXXoXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.",
" XXXoXXXXXXXXXXXOOXXOOOXXOOXOOXXXXXXXXXXXXXXXXX.",
"+oooooooooooooooooooooooooooooooooooooooooooooo.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" @@@ooooooooooooooooooooooooooooooooooooooo@@@@.",
" @@@ooooooooooooooooooooooooooooooooooooooo@@@@.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" @@@...............#@@o@@...............@@o@@@@.",
" @@@.XXXXXXXXXXXXXX#@@o@@.XXXXXXXXXXXXX#@@o@@@@.",
" @@@.XXXXXXXXXXXXXX#@@o@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@O@@.XXXXXXXXXXXXX#@@O@@@@.",
" @@@.XXXXXXXXXXXXXX#@@o@@.XXXXXXXXXXXXX#@@o@@@@.",
" @@@.XXXXXXXXXXXXXX#@@o@@.XXXXXXXXXXXXX#@@o@@@@.",
" @@@.###############@@o@@.##############@@o@@@@.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" @@@ooooooooooooooooooooooooooooooooooooooo@@@@.",
" @@@ooooooooooooooooooooooooooooooooooooooo@@@@.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" ##############################################.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" @            .@@@            .@@@           .@.",
" @ @@@@@@@@@@@.@@@ @@@@@@@@@@@.@@@ @@@@@@@@@@.@.",
" @ @@@@@@@@@@@.@@@ @@@@@@@@@@@.@@@ @@@@@@@@@@.@.",
" @ ............@@@ ............@@@ ...........@.",
" @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@.",
" ..............................................."};
