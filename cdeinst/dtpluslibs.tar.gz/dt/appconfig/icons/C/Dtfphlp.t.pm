/* XPM */
/* $XConsortium: Dtfphlp.t.pm /main/3 1995/07/18 16:38:08 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * fphelp [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 13 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X	s iconColor1	m black	c black",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray3     m white c #adadadadadad",
"+    s iconGray7     m black c #424242424242",
"@    s topShadowColor m white c #bdbdbdbdbdbd",
"#    s background    m black c #949494949494",
"$	s iconColor3	m black	c red",
"%	s iconColor6	m white	c yellow",
"&	s iconColor5	m black	c blue",
"*    s bottomShadowColor m black c #636363636363",
"=    s iconGray4     m white c #949494949494",
/* pixels */
"                ",
" ...........X   ",
" oooooooooooX   ",
" OXXXXXXXXXXX   ",
" O++.+++++++X   ",
" O++++++++++X   ",
" O......XX.XX   ",
" O..........X   ",
"@@@@@@@@@@X@X@#@",
"#########@######",
"#$#%#&###@++++##",
"****************",
" O=.=O=.=O..X   ",
" O==========X   ",
" XXXXXXXXXXXX   ",
"                "};
