/* XPM */
/* $XConsortium: Fplite.t.pm /main/3 1995/07/18 16:59:02 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Flite [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s iconGray4     m white c #949494949494",
"o    s topShadowColor m white c #bdbdbdbdbdbd",
"O	s iconColor6	m white	c yellow",
"+    s iconGray7     m black c #424242424242",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"................",
".XXXXXXXXXXXXXXo",
".XOXOXOXOXOXOX+o",
".X+++++++++++++o",
".ooooooooooooooo",
"                ",
"                ",
"                ",
"                ",
"                ",
"                "};
