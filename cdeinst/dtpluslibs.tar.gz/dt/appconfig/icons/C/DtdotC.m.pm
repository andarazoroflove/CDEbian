/* XPM */
/* $XConsortium: DtdotC.m.pm /main/3 1995/07/18 16:36:17 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * DtdotC_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 5 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray5     m black c #737373737373",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXOOOOOOXXOXXXXXo.......",
" XXXXXXXXOOOOOOOOOOXXXXXo.......",
" XXXXXXXOOOOXXXXOOOXXXXXo.......",
" XXXXXXOOOOXXXXXXOOXXXXXo.......",
" XXXXXXOOOOXXXXXXOOXXXXXo.......",
" XXXXXOOOOXXXXXXXXOXXXXXo.......",
" XXXXXOOOOXXXXXXXXOXXXXXo.......",
" XXXXXOOOOXXXXXXXXXXXXXXo.......",
" XXXXXOOOOXXXXXXXXXXXXXXo.......",
" XXXXXOOOOXXXXXXXXXXXXXXo.......",
" XXXXXOOOOXXXXXXXXXXXXXXo.......",
" XXXXXOOOOXXXXXXXXXXXXXXo.......",
" XXXXXOOOOXXXXXXXXOXXXXXo.......",
" XXXXXXOOOOXXXXXXXOXXXXXo.......",
" XXXOXXOOOOXXXXXXOOXXXXXo.......",
" XXOOOXXOOOOXXXXOOXXXXXXo.......",
" XXXOXXXXXOOOOOOOXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
