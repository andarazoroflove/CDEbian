/* XPM */
/* $XConsortium: DtABbix.t.pm /main/3 1995/07/18 16:12:04 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtABbix_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 12 1 0 0",
/* colors */
"     s topShadowColor m white c #bdbdbdbdbdbd",
".    s iconGray2     m white c #bdbdbdbdbdbd",
"X    s bottomShadowColor m black c #636363636363",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+	s iconColor2	m white	c white",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray6     m black c #636363636363",
"$	s iconColor4	m white	c green",
"%    s iconGray5     m black c #737373737373",
"&	s iconColor1	m black	c black",
"*	s iconColor5	m black	c blue",
/* pixels */
"                ",
" ..............X",
" ..oOO.O.......X",
" .+O+@OO#......X",
" .+$@%oo#......X",
" .+$$%oo#......X",
" .+$%&@o#+++++.X",
" .+$%#$@#oooo&.X",
" .+$%#$$#@@oo&.X",
" .+#%####o@oo&.X",
" ...%#...o@o+++X",
" ......+o@@@+*&X",
" ......+oooo+&&X",
" ......+&&&&&&.X",
" ..............X",
" XXXXXXXXXXXXXXX"};
