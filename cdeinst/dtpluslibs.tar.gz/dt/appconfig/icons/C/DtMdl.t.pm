/* XPM */
/* $XConsortium: DtMdl.t.pm /main/3 1995/07/18 16:22:19 drk $ */
static char * DtMdl_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 8 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X    s iconGray1     m white c #dededededede",
"o    s iconGray4     m white c #949494949494",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor4	m white	c green",
"@    s iconGray2     m white c #bdbdbdbdbdbd",
"#    s iconGray5     m black c #737373737373",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"                ",
"........ .......",
".XooXXXXO .Xoo+O",
".XXXXXXXXO .XXXO",
".XXXXXXXXO .XXXO",
".XXXooooO .oXXXO",
".XXX@o@O  .@oXXO",
".XXX##XO  .#XXXO",
".XXXXXXO  .XXXXO",
".OOOOOOO  OOOOOO"};
