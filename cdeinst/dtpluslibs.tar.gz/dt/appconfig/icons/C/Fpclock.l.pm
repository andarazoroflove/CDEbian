/* XPM */
/* $XConsortium: Fpclock.l.pm /main/3 1995/07/18 16:56:09 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * clock_l_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"48 48 6 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s bottomShadowColor m black c #636363636363",
"X    s topShadowColor m white c #bdbdbdbdbdbd",
"o    s background    m black c #949494949494",
"O	s iconColor2	m white	c white",
"+    s selectColor m white c #737373737373",
/* pixels */
"                                                ",
"                                                ",
"                                                ",
"                                                ",
"       ...................................      ",
"      ..XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.X     ",
"     ..XooooooooooooooooOooooooooooooooooX.X    ",
"    ..XooooooooooooooooOOOooooooooooooooooX.X   ",
"    .XoooooooooOooooooooOooooooooOooooooooo.X   ",
"    .Xooooooooo+++++++++++++++++++ooooooooo.X   ",
"    .Xoooooooo+++++++++++++++++++++oooooooo.X   ",
"    .Xooooooo+++++++++++++++++++++++ooooooo.X   ",
"    .Xoooooo+++++++++++++++++++++++++oooooo.X   ",
"    .Xooooo+++++++++++++++++++++++++++ooooo.X   ",
"    .Xoooo+++++++++++++++++++++++++++++oooo.X   ",
"    .XooO+++++++++++++++++++++++++++++++Ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .XoOo+++++++++++++++++++++++++++++++oOo.X   ",
"    .XOOO+++++++++++++++++++++++++++++++OOO.X   ",
"    .XoOo+++++++++++++++++++++++++++++++oOo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .Xooo+++++++++++++++++++++++++++++++ooo.X   ",
"    .XooO+++++++++++++++++++++++++++++++Ooo.X   ",
"    .Xoooo+++++++++++++++++++++++++++++oooo.X   ",
"    .Xooooo+++++++++++++++++++++++++++ooooo.X   ",
"    .Xoooooo+++++++++++++++++++++++++oooooo.X   ",
"    .Xooooooo+++++++++++++++++++++++ooooooo.X   ",
"    .Xoooooooo+++++++++++++++++++++oooooooo.X   ",
"    .Xooooooooo+++++++++++++++++++ooooooooo.X   ",
"    .XoooooooooOooooooooOooooooooOooooooooo.X   ",
"    ..XooooooooooooooooOOOoooooooooooooooo.XX   ",
"     X.XooooooooooooooooOoooooooooooooooo.XX    ",
"      X..................................XX     ",
"       XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX      ",
"                                                ",
"                                                ",
"                                                "};
