/* XPM */
/* $XConsortium: Fpexit.t.pm /main/3 1995/07/18 16:56:50 drk $ */
static char * Fpexit_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 7 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray7     m black c #424242424242",
"X    s bottomShadowColor m black c #636363636363",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray2     m white c #bdbdbdbdbdbd",
"+    s topShadowColor m white c #bdbdbdbdbdbd",
"@    s iconGray8     m black c #212121212121",
/* pixels */
"                ",
"                ",
"                ",
"................",
"Xooooooooooooooo",
"XoOOOOOOOOOOOO.+",
"Xo@@O@O@O@O@@@.+",
"Xo@OO@O@O@OO@O.+",
"Xo@OOO@OO@OO@O.+",
"Xo@@OO@OO@OO@O.+",
"Xo@OOO@OO@OO@O.+",
"Xo@OO@O@O@OO@O.+",
"Xo@@O@O@O@OO@O.+",
".oOOOOOOOOOOOO.+",
".o.............+",
".+++++++++++++++"};
