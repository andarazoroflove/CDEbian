/* XPM */
/* $XConsortium: Dtdeflt.t.pm /main/3 1995/07/18 16:34:00 drk $ */
static char * Dtdeflt_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 4 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray1     m white c #dededededede",
"X    s iconGray7     m black c #424242424242",
"o    s iconGray6     m black c #636363636363",
/* pixels */
"  ............X ",
"  ...ooo......X ",
"  .oo...o.....X ",
"  .o....o.....X ",
"  .....oo.....X ",
"  ....o...ooo.X ",
"  ...o..oo...oX ",
"  ...o..o....oX ",
"  ..........ooX ",
"  ...o.....o..X ",
"  ........o...X ",
"  ........o...X ",
"  ............X ",
"  ........o...X ",
"  ............X ",
"   XXXXXXXXXXXX "};
