/* XPM */
/* $XConsortium: Dtshar.m.pm /main/3 1995/07/18 17:11:43 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtshar_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 9 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray5     m black c #737373737373",
"@    s iconGray6     m black c #636363636363",
"#    s iconGray7     m black c #424242424242",
"$    s iconGray8     m black c #212121212121",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXOXXOXXOXXOXXXXXXXXXXo.......",
" XXOoOOoOOoOOoOXXXXXXXXXo.......",
" XXXOXXOXXOXXOXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX+++XO++XOX@@#X@#OXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX#@@X@@@##X@@@@X@#OXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@@@X@XO@#X@XO@XXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@@@X##X@@X##X@@@#XXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@@@@XO@@@#XO@@@@++XXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@X##O##X##O##X##XXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXOO@X@@@X@X@@@XO@@OXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@@@XO@O##XO@O#X##OXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXOO@X@X@O#X@X@@XXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX++@X@#X@OXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXX@O@@X++++XXOXXOXXOXXo.......",
" XXXXXXXXXXXXXOoOOoOO$OXo.......",
" XXXXXXXXXXXXXXOXXOXXOXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
