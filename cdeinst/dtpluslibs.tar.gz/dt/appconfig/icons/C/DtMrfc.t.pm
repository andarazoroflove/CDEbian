/* XPM */
/* $XConsortium: DtMrfc.t.pm /main/3 1995/07/18 16:23:35 drk $ */
static char * DtMrfc_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".	s iconColor2	m white	c white",
"X	s iconColor5	m black	c blue",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray7     m black c #424242424242",
"@    s iconGray3     m white c #adadadadadad",
"#    s iconGray8     m black c #212121212121",
"$    s iconGray5     m black c #737373737373",
/* pixels */
"                ",
"                ",
"                ",
"         ...... ",
"        .XXXXXXo",
" ooooooooXOXOXO+",
".............+O+",
".@@@@@@@@@@@@+O+",
".@............#+",
".@.@.@......X.#+",
".@............#+",
".@....@$@$@...#+",
".@....OO.O....#+",
".@............#+",
".@++###########+",
" ++++++++++++++ "};
