/* XPM */
/* $XConsortium: DtCMapt.m.pm /main/3 1995/07/18 16:18:49 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * DtCMapt_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 12 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray4     m white c #949494949494",
"X	s iconColor3	m black	c red",
"o    s iconGray5     m black c #737373737373",
"O    s iconGray6     m black c #636363636363",
"+	s iconColor2	m white	c white",
"@    s iconGray1     m white c #dededededede",
"#    s iconGray2     m white c #bdbdbdbdbdbd",
"$    s iconGray3     m white c #adadadadadad",
"%	s iconColor6	m white	c yellow",
"&    s background    m black c #949494949494",
"*	s iconColor1	m black	c black",
/* pixels */
"                                ",
"                                ",
"                                ",
"                                ",
"                        .       ",
"                       .Xo      ",
"                      .X.Xo     ",
"                     OX.XoXo    ",
" +++o ++++++++++++++O+OXoXoo+   ",
"+@@@o +@@@@@@@@@@@@O++@OXo##@O  ",
"+@@oo ++@@@@@@@@@@O+O@@#O$$@@O  ",
"+@@o   +@@@@@@@@@O+%.O#O&&+@@O  ",
"+@@+++++@@@@@@@@O+%.%.O$$++@@O  ",
"+@@@@@@@@@@@@@@O+%.%.O##@@@@@O  ",
"+@@@@@@@@@@@@@O+%.%.O##@@@@@@O  ",
"+@@@@@@@@@@@@O+%.%.O##@@@@@@@O  ",
"+@@@@$@@@@$@O+%.%.O##$@@@@@@@O  ",
"+@@.....@..O+%.%.O.#....@@@@@O  ",
"+@@@$@$@$@O+%.%.O##@$@****@@@O  ",
"+@@@@@@@@O+%.%.O##@@**@@o@**@O  ",
"+@@@@$@@O+%.%.O##@@*@@@*@@@@*O  ",
"+@@...@O+%.%.O.#..*@@@@*$@@@@*  ",
"+@@@$@O+%.%.O$#$@*@@@@@*$@@*@@* ",
"+@@@@O+%.%.O##@@@*@@@@@*$@*$@@* ",
"+@@@O+O.%.O##@@$@*oo@@@*$*$@oo* ",
"+@@.O@+O.O#..@...*@@@@@*$$@@@@* ",
"+@$@OO##O##@@@$@@*@@@@@$@@@@@@* ",
"+@@@OOOO##@@@@@@@*@@@@@@@@@@@@* ",
"+@@@@@###@@@@@@@@@*@@@@@@@@@@*  ",
"+@@@@@@@@@@@@@@@@@@*@@@@o@@@*O  ",
"+@@@@@@@@@@@@@@@@@@@**@@o@**@O  ",
" OOOOOOOOOOOOOOOOOOOOO****OOO   "};
