/* XPM */
/* $XConsortium: Dtcore.t.pm /main/3 1995/07/18 17:10:27 drk $ */
static char * Dtcore_t_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"18 22 6 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor3	m black	c red",
"O    s iconGray8     m black c #212121212121",
"+    s iconGray7     m black c #424242424242",
/* pixels */
"            ......",
" XXX XXXXoXO......",
" XXX XXXoooO......",
"  XX XXoXooO......",
"   XXXoXoo+O......",
" X  XXXXo+XO......",
" XXX  XX+XXO......",
"       X    ......",
" XXX   XXXX+......",
" XXoX X XXXO......",
" XoXoXX  XXO......",
" oXoo+ X  XO......",
" ooo+X XX XO......",
" Xo+XX XXXXO......",
" XXXXXXXXXXO......",
"OOOOOOOOOOOO......",
"..................",
"..................",
"..................",
"..................",
"..................",
".................."};
