/* XPM */
/* $XConsortium: DtBento.t.pm /main/3 1995/07/18 16:17:07 drk $ */
static char * DtBento [] = {
/* width height ncolors cpp [x_hot y_hot] */
"16 16 9 1 0 0",
/* colors */
" 	s none	m none	c none",
".    s iconGray3     m white c #adadadadadad",
"X	s iconColor2	m white	c white",
"o    s iconGray1     m white c #dededededede",
"O    s iconGray4     m white c #949494949494",
"+    s iconGray5     m black c #737373737373",
"@	s iconColor4	m white	c green",
"#    s iconGray2     m white c #bdbdbdbdbdbd",
"$    s iconGray6     m black c #636363636363",
/* pixels */
"                ",
"                ",
"                ",
"                ",
"                ",
"   ..........   ",
"  XXXXXXXXXXXX  ",
"  XooooooooooO  ",
" .X++oooooo.@O. ",
"OXXoooooo..ooO.+",
"O+++..oooooo###+",
"OX..+.ooooo#...+",
"OXo.+++++++#...+",
"OXo............+",
"OXo............+",
"$++++++++++++++$"};
