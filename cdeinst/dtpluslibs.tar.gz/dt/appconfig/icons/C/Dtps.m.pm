/* XPM */
/* $XConsortium: Dtps.m.pm /main/3 1995/07/18 16:47:48 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * Dtps_m_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 8 1 0 0",
/* colors */
" 	s iconColor2	m white	c white",
".	s none	m none	c none",
"X    s iconGray2     m white c #bdbdbdbdbdbd",
"o	s iconColor1	m black	c black",
"O    s iconGray7     m black c #424242424242",
"+    s iconGray1     m white c #dededededede",
"@	s iconColor5	m black	c blue",
"#    s iconGray3     m white c #adadadadadad",
/* pixels */
"                         .......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXXXXXXXOOXOOXXXOOOOOXXo.......",
" XXXooXOOOOOXOOXOOOXXOXXo.......",
" XXXXXXXOOOXXOOXOOXXXXXXo.......",
" XXooXXXOOXXOOOXXOOOXXXXo.......",
" XXXXXXOOOXXOOXXXXOOXXXXo.......",
" XXooXXOOXXOOOXXXOOOXXXXo.......",
" XXXXXOOOOXOOXOXXOOXXXXXo.......",
" XXoXXOOXOOOXXOOOOXXOOXXo.......",
" XXXXOOOXXXXXXXXXXXXXXXXo.......",
" XXXXOOXXoXoooXOooXoOOXXo.......",
" XXXOOOXXXXXXXXXXXXXXXXXo.......",
" XXOOOOOXOOooXOooXOOOXXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXoOOooOoXOooXooOOoooXXo.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" XXOOOOXXOOooXOOOO++++++++++++++",
" XXXXXXXXXXXXXXXXX+@O@O@O@O@O@Oo",
" XXXXXXXXXXXXXXXXX+O   O@O   O@o",
" XXOOOXOOXoooXoXXO+@ @O O O@O Oo",
" XXXXXXXXXXXXXXXXX+O O@ @ @O@O@o",
" XXOOXOOXOOXoooXXO+@   @O@   @Oo",
" XXXXXXXXXXXXXXXXX+O O@O@O@O@ @o",
" XXOOOOXOOXOOXoOOo+@ @O@O O@O Oo",
" XXXXXXXXXXXXXXXXX+O O@O@O   O@o",
" XXOOXOOOooXXXXXXX+@O@O@O@O@O@Oo",
" XXXXXXXXXXXXXXXXX+ooooooooooooo",
" XXXXXXXXXXXXXXXXXX######.......",
" XXXXXXXXXXXXXXXXXXXXXXXo.......",
" oooooooooooooooooooooooo......."};
