/* XPM */
/* $XConsortium: warnicon.pm /main/3 1995/07/18 17:15:36 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/
static char * warnicon [] = {
/* width height ncolors cpp [x_hot y_hot] */
"32 32 4 1 -1 -1",
/* colors */
" 	s none	m none	c none",
".	s iconColor1	m black	c black",
"X	s iconColor3	m black	c red",
"o	s iconColor6	m white	c yellow",
/* pixels */
"                                ",
"             .....       X      ",
"            .ooooo.     XXX     ",
"           .ooXXXoo.    XXXX    ",
"          .ooXXXXXoo. XXXXXXX   ",
"          .oXXXXXXXo. XXXXXXX   ",
"         .ooXXXXXXXooXXXXXXX    ",
"        .ooXXXXXXXXXoXXXXXX     ",
"        .oXXXXXXXXXoXXXXX       ",
"       .ooXXXXXXXXoooXX         ",
"      .ooXXXXXXXXoooooXXX       ",
"      .oXXXXXXXXooooooXoX       ",
"     .ooXXXXXXXooooooXXoo.      ",
"    .ooXXXXXXXooooooXXXXoo.     ",
"    .oXXXXXXXooooooXXXXXXo.     ",
"   .ooXXXXXXooooooXXXXXXXoo.    ",
"  .ooXXXXXXXXXoooXXXXXXXXXoo.   ",
"  .oXXXXXXXXXXooooXXXXXXXXXo.   ",
" .ooXXXXXXXXXooooooXXXXXXXXoo.  ",
".ooXXXXXXXXXoooooXXXXXXXXXXXo.  ",
".ooXXXXXXXXoooooXXXXXXXXXXXXoo. ",
".oXXXXXXXXooooXXXXXXXXXXXXXXXo. ",
".oXXXXXXXXoooXXXXXXXXXXXXXXXXo. ",
".oXXXXXXXoooXXXXXXXXXXXXXXXXXo. ",
".ooXXXXXoooooXXXXXXXXXXXXXXXoo. ",
"..oXXXXooooXXXXXXXXXXXXXXXXXo.  ",
" .oooooooXXXXXXXXXXXXXXXXXooo.  ",
"  ..oXXXooooooooooooooooooo..   ",
"   XXXX....................     ",
"  XXX                           ",
" XX                             ",
" X                              "};
