!######################################################################
!#
!#     Palettes
!#
!#     Common Desktop Environment (CDE)
!#
!#     Palette file used for localization of backdrop names
!#
!#     (c) Copyright 1993, 1994 Hewlett-Packard Company
!#     (c) Copyright 1993, 1994 International Business Machines Corp.
!#     (c) Copyright 1993, 1994 Sun Microsystems, Inc.
!#     (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary 
!#	   of Novell, Inc.
!#
!#
!######################################################################

!###
!#
!#   C palette names followed by message tags for the translated names 
!#   
!###

Palettes*Alpine.desc: Alpine
Palettes*Arizona.desc: Arizona
Palettes*Black.desc: Black
Palettes*BlackWhite.desc: BlackWhite
Palettes*Broica.desc: Broica
Palettes*Cabernet.desc: Cabernet
Palettes*Camouflage.desc: Camouflage
Palettes*Charcoal.desc: Charcoal
Palettes*Chocolate.desc: Chocolate
Palettes*Cinnamon.desc: Cinnamon
Palettes*Clay.desc: Clay
Palettes*Default.desc: Default
Palettes*Golden.desc: Golden
Palettes*GrayScale.desc: GrayScale
Palettes*Lilac.desc: Lilac
Palettes*Mustard.desc: Mustard
Palettes*Neptune.desc: Neptune
Palettes*NorthernSky.desc: NorthernSky
Palettes*Nutmeg.desc: Nutmeg
Palettes*Olive.desc: Olive
Palettes*Orchid.desc: Orchid
Palettes*Sand.desc: Sand
Palettes*SantaFe.desc: SantaFe
Palettes*Savannah.desc: Savannah
Palettes*SeaFoam.desc: SeaFoam
Palettes*SoftBlue.desc: SoftBlue
Palettes*SouthWest.desc: SouthWest
Palettes*Tundra.desc: Tundra
Palettes*Urchin.desc: Urchin
Palettes*Wheat.desc: Wheat
Palettes*White.desc: White
Palettes*WhiteBlack.desc: WhiteBlack


Palettes*BeigeRose.desc: BeigeRose
Palettes*Crimson.desc: Crimson
Palettes*DarkGold.desc: DarkGold
Palettes*Delphinium.desc: Delphinium
Palettes*Desert.desc: Desert
Palettes*Grass.desc: Grass
Palettes*PBNJ.desc: PBNJ
Palettes*SkyRed.desc: SkyRed
Palettes*Summer.desc: Summer


