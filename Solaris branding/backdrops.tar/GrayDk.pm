/* XPM */
/*********************************************************************
*  (c) Copyright 1993, 1994, 1995 Sun Microsystems, Inc.
**********************************************************************/
static char * GrayDk_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"8 8 1 1 -1 -1",
/* colors */
" 	s iconGray5	m black	c #737373737373",
/* pixels */
"        ",
"        ",
"        ",
"        ",
"        ",
"        ",
"        ",
"        "};
