/* XPM */
/*********************************************************************
*  (c) Copyright 1993, 1994, 1995 Sun Microsystems, Inc.
**********************************************************************/
static char * GrayLt_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"8 8 1 1 -1 -1",
/* colors */
" 	s iconGray1	m white	c #dededededede",
/* pixels */
"        ",
"        ",
"        ",
"        ",
"        ",
"        ",
"        ",
"        "};
