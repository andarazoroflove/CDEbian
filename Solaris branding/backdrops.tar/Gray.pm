/* XPM */
/*********************************************************************
*  (c) Copyright 1993, 1994, 1995 Sun Microsystems, Inc.
**********************************************************************/
static char * Gray_pm[] = {
/* width height ncolors cpp [x_hot y_hot] */
"4 4 1 1 -1 -1",
/* colors */
" 	s iconGray3	m white	c #adadadadadad",
/* pixels */
"    ",
"    ",
"    ",
"    "};
